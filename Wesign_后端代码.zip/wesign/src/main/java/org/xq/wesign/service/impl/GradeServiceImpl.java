package org.xq.wesign.service.impl;

import com.alibaba.druid.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.xq.wesign.bean.*;
import org.xq.wesign.dao.CourseGradeLinkDao;
import org.xq.wesign.dao.GradeDao;
import org.xq.wesign.exception.FriendException;
import org.xq.wesign.service.GradeService;
import org.xq.wesign.utils.Util;

import java.util.List;
@Service
@Transactional
public class GradeServiceImpl implements GradeService {

    @Autowired
    private GradeDao gradeDao;

    @Autowired
    private CourseGradeLinkDao courseGradeLinkDao;

    @Override
    public void insertGrade(Grade grade) {
        if(grade==null) {
            throw new FriendException("班级信息为空");
        }
        String gradeName=grade.getGradeName();
        String place=grade.getPlace();
        String longitude=grade.getLongitude();
        String latitude=grade.getLatitude();
        String teacherId=grade.getTeacherId();
        if(StringUtils.isEmpty(gradeName)||StringUtils.isEmpty(place)||StringUtils.isEmpty(longitude)||StringUtils.isEmpty(latitude)||StringUtils.isEmpty(teacherId)){
            throw new FriendException("班级信息不完整");
        }
        grade.setGradeId(Util.getUuid());
        gradeDao.insertGrade(grade);
        List<Course> courseList=grade.getCourseList();
        if(courseList!=null&&courseList.size()!=0){
            for(Course course:courseList){
                CourseGradeLink courseGradeLink=new CourseGradeLink();
                courseGradeLink.setCourseId(course.getCourseId());
                courseGradeLink.setCourseGradeLinkId(Util.getUuid());
                courseGradeLink.setGradeId(grade.getGradeId());
                courseGradeLinkDao.insertCourseGradeLink(courseGradeLink);
            }
        }
    }

    @Override
    public Grade getGradeById(String id) {
        if(StringUtils.isEmpty(id)){
            throw new FriendException("id不能为空");
        }else{
            Grade grade=gradeDao.getGradeById(id);
            if(grade==null){
                throw new FriendException("不存在此班级信息");
            }else{
                return grade;
            }
        }
    }

    @Override
    public void updateGrade(Grade grade) {
        if(grade==null) {
            throw new FriendException("班级信息为空");
        }
        String gradeId=grade.getGradeId();
        String teacherId=grade.getTeacherId();
        if(StringUtils.isEmpty(gradeId)||StringUtils.isEmpty(teacherId)){
            throw new FriendException("班级信息不完整");
        }
        List<Course> courseList=grade.getCourseList();
        if(courseList!=null){
            courseGradeLinkDao.deleteCourseGradeLinkByGradeId(gradeId);
            for(Course course:courseList) {
                CourseGradeLink courseGradeLink=new CourseGradeLink();
                courseGradeLink.setCourseGradeLinkId(Util.getUuid());
                courseGradeLink.setGradeId(gradeId);
                courseGradeLink.setCourseId(course.getCourseId());
                courseGradeLinkDao.insertCourseGradeLink(courseGradeLink);
            }
        }
        gradeDao.updateGrade(grade);
    }

    @Override
    public List<Grade> getGradePage(RequestPage requestPage) {
        if(requestPage==null) {
            throw new FriendException("分页信息不能为空");
        }
        requestPage.setBeginPage((requestPage.getPage()-1)*requestPage.getPageSize());
        return gradeDao.getGradePage(requestPage);
    }

    @Override
    public void deleteGrade(String id) {
        if(StringUtils.isEmpty(id)){
            throw new FriendException("id不能为空");
        }else{
            gradeDao.deleteGrade(id);
            courseGradeLinkDao.deleteCourseGradeLinkByGradeId(id);
        }
    }
}
