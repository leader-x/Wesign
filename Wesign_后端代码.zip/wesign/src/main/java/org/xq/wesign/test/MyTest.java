package org.xq.wesign.test;

import java.io.*;

public class MyTest {
    public static void main(String args[]) throws IOException {

        readAllBytes("C:\\Users\\Administrator\\Desktop\\eclipse.platform.ui-master\\eclipse.platform.ui-master_code_vec.json");


    }

    private static byte[] readAllBytes(String pathName) throws IOException {
        File filename = new File(pathName);
        BufferedInputStream in = new BufferedInputStream(new FileInputStream(filename));
        ByteArrayOutputStream out = new ByteArrayOutputStream(1024);
        byte[] temp = new byte[1024];
        int size = 0;
        while ((size = in.read(temp)) != -1) {
            System.out.println(new String(temp));
            out.write(temp, 0, size);
        }
        in.close();
        return out.toByteArray();
    }
}
