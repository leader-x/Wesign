package org.xq.wesign.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.xq.wesign.bean.RequestPage;
import org.xq.wesign.bean.User;
import org.xq.wesign.enumeration.ResponseCode;
import org.xq.wesign.exception.FriendException;
import org.xq.wesign.other.ServerResponse;
import org.xq.wesign.service.UserInfoService;

import java.util.List;

@RestController
@RequestMapping("/userInfo")
public class UserInfoController {

    @Autowired
    private UserInfoService userInfoService;

    @PostMapping
    public ServerResponse insertUserInfo(@RequestBody User user){
        userInfoService.insertUserInfo(user);
        return new ServerResponse(ResponseCode.SUCCESS.getCode(),"用户基本信息插入成功");
    }

    @GetMapping("/{id}")
    public ServerResponse getUserInfoById(@PathVariable String id){
        User user=userInfoService.getUserInfoById(id);
        return new ServerResponse(ResponseCode.SUCCESS.getCode(),user,"用户基本信息查询成功");
    }

    @PutMapping
    public ServerResponse updateUserInfo(@RequestBody User user) {
        userInfoService.updateUserInfo(user);
        return new ServerResponse(ResponseCode.SUCCESS.getCode(),"用户基本信息更新成功");
    }

    @GetMapping
    public ServerResponse getUserInfoPage(String page,String pageSize){
        try {
            RequestPage requestPage=new RequestPage(Integer.parseInt(page),Integer.parseInt(pageSize));
            List<User> userList=userInfoService.getUserInfoPage(requestPage);
            return new ServerResponse(ResponseCode.SUCCESS.getCode(),userList,"用户基本信息查询成功");
        }catch (Exception e){
            throw new FriendException("页数和页数大小必须是整数");
        }
    }

    @DeleteMapping("/{id}")
    public ServerResponse deleteUserInfo(@PathVariable String id){
        userInfoService.deleteUserInfo(id);
        return new ServerResponse(ResponseCode.SUCCESS.getCode(),"用户基本信息删除成功");
    }
}
