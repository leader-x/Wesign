package org.xq.wesign.service.impl;

import com.alibaba.druid.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.xq.wesign.bean.RequestPage;
import org.xq.wesign.bean.User;
import org.xq.wesign.dao.UserInfoDao;
import org.xq.wesign.exception.FriendException;
import org.xq.wesign.service.UserInfoService;
import org.xq.wesign.utils.Util;

import java.util.List;

@Service
@Transactional
public class UserInfoServiceImpl implements UserInfoService {

    @Autowired
    private UserInfoDao userInfoDao;

    @Override
    public void insertUserInfo(User user) {
        if(user==null) {
            throw new FriendException("用户基本信息为空");
        }
        String realName=user.getRealName();
        String telephone=user.getTelephone();
        String courseId=user.getCourseId();
        if(StringUtils.isEmpty(realName)||StringUtils.isEmpty(telephone)||StringUtils.isEmpty(courseId)){
            throw new FriendException("用户基本信息不完整");
        }
        user.setUserInfoId(Util.getUuid());
        userInfoDao.insertUserInfo(user);
    }

    @Override
    public User getUserInfoById(String id) {
        if(StringUtils.isEmpty(id)){
            throw new FriendException("id不能为空");
        }else{
            User user=userInfoDao.getUserInfoById(id);
            if(user==null){
                throw new FriendException("不存在此用户基本信息");
            }else{
                return user;
            }
        }
    }

    @Override
    public void updateUserInfo(User user) {
        if(user==null) {
            throw new FriendException("用户基本信息为空");
        }
        String userInfoId=user.getUserInfoId();
        if(StringUtils.isEmpty(userInfoId)){
            throw new FriendException("用户基本信息不完整");
        }
        userInfoDao.updateUserInfo(user);
    }

    @Override
    public List<User> getUserInfoPage(RequestPage requestPage) {
        if(requestPage==null) {
            throw new FriendException("分页信息不能为空");
        }
        requestPage.setBeginPage((requestPage.getPage()-1)*requestPage.getPageSize());
        return userInfoDao.getUserInfoPage(requestPage);
    }

    @Override
    public void deleteUserInfo(String id) {
        if(StringUtils.isEmpty(id)){
            throw new FriendException("id不能为空");
        }else{
            userInfoDao.deleteUserInfo(id);
        }
    }
}
