package org.xq.wesign.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.xq.wesign.bean.Course;
import org.xq.wesign.bean.RequestPage;
import org.xq.wesign.enumeration.ResponseCode;
import org.xq.wesign.exception.FriendException;
import org.xq.wesign.other.ServerResponse;
import org.xq.wesign.service.CourseService;

import java.util.List;

@RestController
@RequestMapping("/course")
public class CourseController {
    @Autowired
    private CourseService courseService;

    @PostMapping
    public ServerResponse insertCourse(@RequestBody Course course){
        courseService.insertCourse(course);
        return new ServerResponse(ResponseCode.SUCCESS.getCode(),"课程信息插入成功");
    }

    @GetMapping("/{id}")
    public ServerResponse getCourseById(@PathVariable String id){
        Course course=courseService.getCourseById(id);
        return new ServerResponse(ResponseCode.SUCCESS.getCode(),course,"课程信息查询成功");
    }

    @PutMapping
    public ServerResponse updateCourse(@RequestBody Course course){
        courseService.updateCourse(course);
        return new ServerResponse(ResponseCode.SUCCESS.getCode(),"课程信息更新成功");
    }

    @GetMapping
    public ServerResponse getCoursePage(String page,String pageSize){
        try {
            RequestPage requestPage=new RequestPage(Integer.parseInt(page),Integer.parseInt(pageSize));
            List<Course> courseList=courseService.getCoursePage(requestPage);
            return new ServerResponse(ResponseCode.SUCCESS.getCode(),courseList,"课程信息查询成功");
        }catch (Exception e){
            throw new FriendException("页数和页数大小必须是整数");
        }
    }

    @DeleteMapping("/{id}")
    public ServerResponse deleteCourse(@PathVariable String id){
        courseService.deleteCourse(id);
        return new ServerResponse(ResponseCode.SUCCESS.getCode(),"课程信息删除成功");
    }

}
