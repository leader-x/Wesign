package org.xq.wesign.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.xq.wesign.bean.RequestPage;
import org.xq.wesign.bean.Sign;
import org.xq.wesign.enumeration.ResponseCode;
import org.xq.wesign.exception.FriendException;
import org.xq.wesign.other.ServerResponse;
import org.xq.wesign.service.SignService;

import java.util.List;

@RestController
@RequestMapping("/sign")
public class SignController {

    @Autowired
    private SignService signService;

    @PostMapping
    public ServerResponse insertSign(@RequestBody Sign sign){
        signService.insertSign(sign);
        return new ServerResponse(ResponseCode.SUCCESS.getCode(),"签到信息插入成功");
    }

    @GetMapping("/{id}")
    public ServerResponse getSignById(@PathVariable String id){
        Sign sign=signService.getSignById(id);
        return new ServerResponse(ResponseCode.SUCCESS.getCode(),sign,"签到信息查询成功");
    }

    @PutMapping
    public ServerResponse updateSign(@RequestBody Sign sign){
        signService.updateSign(sign);
        return new ServerResponse(ResponseCode.SUCCESS.getCode(),"签到信息更新成功");
    }

    @GetMapping
    public ServerResponse getSignPage(String page,String pageSize){
        try {
            RequestPage requestPage=new RequestPage(Integer.parseInt(page),Integer.parseInt(pageSize));
            List<Sign> signList=signService.getSignPage(requestPage);
            return new ServerResponse(ResponseCode.SUCCESS.getCode(),signList,"签到信息查询成功");
        }catch (Exception e){
            throw new FriendException("页数和页数大小必须是整数");
        }
    }

    @DeleteMapping("/{id}")
    public ServerResponse deleteGrade(@PathVariable String id){
        signService.deleteSign(id);
        return new ServerResponse(ResponseCode.SUCCESS.getCode(),"签到信息删除成功");
    }
}
