package org.xq.wesign.test;

public interface MessageService {
    String getMessage();
}
