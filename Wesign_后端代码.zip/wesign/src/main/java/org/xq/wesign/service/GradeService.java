package org.xq.wesign.service;

import org.xq.wesign.bean.Grade;
import org.xq.wesign.bean.RequestPage;

import java.util.List;

public interface GradeService {
    void insertGrade(Grade grade);

    Grade getGradeById(String id);

    void updateGrade(Grade grade);

    List<Grade> getGradePage(RequestPage requestPage);

    void deleteGrade(String id);
}
