package org.xq.wesign.service.impl;

import com.alibaba.druid.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.xq.wesign.bean.Dict;
import org.xq.wesign.bean.RequestPage;
import org.xq.wesign.dao.DictDao;
import org.xq.wesign.exception.FriendException;
import org.xq.wesign.service.DictService;
import org.xq.wesign.utils.Util;

import java.util.List;

@Service
@Transactional
public class DictServiceImpl implements DictService {

    @Autowired
    private DictDao dictDao;

    @Override
    public void insertDict(Dict dict) {
        if(dict==null) {
            throw new FriendException("数据字典信息为空");
        }
        String key=dict.getKey();
        String value=dict.getValue();
        String dictName=dict.getDictName();
        if(StringUtils.isEmpty(dictName)||StringUtils.isEmpty(key)||StringUtils.isEmpty(value)){
            throw new FriendException("数据字典信息不完整");
        }
        dict.setDictId(Util.getUuid());
        dictDao.insertDict(dict);
    }

    @Override
    public Dict getDictById(String id) {
        if(StringUtils.isEmpty(id)){
            throw new FriendException("id不能为空");
        }else{
            Dict dict=dictDao.getDictById(id);
            if(dict==null){
                throw new FriendException("不存在此数据字典信息");
            }else{
                return dict;
            }
        }
    }

    @Override
    public void updateDict(Dict dict) {
        if(dict==null) {
            throw new FriendException("数据字典为空");
        }
        String dictId=dict.getDictId();
        if(StringUtils.isEmpty(dictId)){
            throw new FriendException("数据字典信息不完整");
        }
        dictDao.updateDict(dict);
    }

    @Override
    public List<Dict> getDictPage(RequestPage requestPage) {
        if(requestPage==null) {
            throw new FriendException("分页信息不能为空");
        }
        requestPage.setBeginPage((requestPage.getPage()-1)*requestPage.getPageSize());
        return dictDao.getDictPage(requestPage);
    }

    @Override
    public void deleteDict(String id) {
        if(StringUtils.isEmpty(id)){
            throw new FriendException("id不能为空");
        }else{
            dictDao.deleteDict(id);
        }
    }
}
