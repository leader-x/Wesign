package org.xq.wesign.bean;

import java.io.Serializable;

public class RequestPage {

    private int pageSize;
    private int page;

    private int beginPage;

    public RequestPage(int page,int pageSize){
        this.page=page;
        this.pageSize=pageSize;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getBeginPage() {
        return beginPage;
    }

    public void setBeginPage(int beginPage) {
        this.beginPage = beginPage;
    }

}
