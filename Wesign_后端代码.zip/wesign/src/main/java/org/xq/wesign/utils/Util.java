package org.xq.wesign.utils;

import java.util.UUID;

public class Util {
	/**
	 * 生成uuid
	 * 
	 * @return
	 */
	public static String getUuid() {
		return UUID.randomUUID().toString().replaceAll("-", "");
	}

}
