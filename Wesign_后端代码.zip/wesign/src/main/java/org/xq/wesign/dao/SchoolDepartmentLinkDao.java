package org.xq.wesign.dao;

import org.apache.ibatis.annotations.Mapper;
import org.xq.wesign.bean.SchoolDepartmentLink;
@Mapper
public interface SchoolDepartmentLinkDao {

    int insertSchoolDepartmentLink(SchoolDepartmentLink schoolDepartmentLink);

    int updateSchoolDepartmentLink(SchoolDepartmentLink schoolDepartmentLink);

    int deleteSchoolDepartmentLink(String id);

    int deleteSchoolDepartmentLinkBySchoolId(String id);

    int deleteSchoolDepartmentLinkByDepartmentId(String id);
}
