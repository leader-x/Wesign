package org.xq.wesign.controller;

import com.alibaba.druid.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.xq.wesign.bean.RequestPage;
import org.xq.wesign.bean.User;
import org.xq.wesign.enumeration.ResponseCode;
import org.xq.wesign.exception.FriendException;
import org.xq.wesign.other.ServerResponse;
import org.xq.wesign.service.UserLoginService;

import javax.servlet.http.HttpSession;
import java.util.List;

@RestController
@RequestMapping("/userLogin")
public class UserLoginController {

    @Autowired
    private UserLoginService userLoginService;

    @PostMapping
    public ServerResponse insertUserLogin(@RequestBody User user) {
        userLoginService.insertUserLogin(user);
        return new ServerResponse(ResponseCode.SUCCESS.getCode(),"用户登录信息插入成功");
    }

    @GetMapping("/{id}")
    public ServerResponse getUserLoginById(@PathVariable String id){
        User user=userLoginService.getUserLoginById(id);
        return new ServerResponse(ResponseCode.SUCCESS.getCode(),user,"用户登录信息查询成功");
    }

    @PutMapping
    public ServerResponse updateUserLogin(@RequestBody User user) {
        userLoginService.updateUserLogin(user);
        return new ServerResponse(ResponseCode.SUCCESS.getCode(),"用户登录信息更新成功");
    }

    @GetMapping
    public ServerResponse getUserPage(String page,String pageSize){
        try {
            RequestPage requestPage=new RequestPage(Integer.parseInt(page),Integer.parseInt(pageSize));
            List<User> userList=userLoginService.getUserPage(requestPage);
            return new ServerResponse(ResponseCode.SUCCESS.getCode(),userList,"用户信息查询成功");
        }catch (Exception e){
            throw new FriendException("页数和页数大小必须是整数");
        }
    }

    @DeleteMapping("/{id}")
    public ServerResponse deleteUserLogin(@PathVariable String id){
        userLoginService.deleteUserLogin(id);
        return new ServerResponse(ResponseCode.SUCCESS.getCode(),"用户登录信息删除成功");
    }

    @PostMapping("/checkUserLogin")
    public ServerResponse checkUserLogin(@RequestBody User user, HttpSession httpSession) {
        User loginUser=userLoginService.checkUserLogin(user);
        httpSession.setAttribute("userId",loginUser.getUserId());
        return new ServerResponse(ResponseCode.SUCCESS.getCode(),loginUser,"用户登录信息删除成功");
    }

    @PostMapping("/loginOut")
    public ServerResponse loginOut(HttpSession session){
        String userId=session.getAttribute("loginToken").toString();
        if(StringUtils.isEmpty(userId)){
            return new ServerResponse(ResponseCode.ERROR.getCode(),"尚未登录,没有用户可以登出");
        }else{
            session.removeAttribute("loginToken");
            return new ServerResponse(ResponseCode.SUCCESS.getCode(),"登出成功");
        }
    }
}
