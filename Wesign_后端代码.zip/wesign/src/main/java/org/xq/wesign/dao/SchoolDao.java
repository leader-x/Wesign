package org.xq.wesign.dao;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Service;
import org.xq.wesign.bean.RequestPage;
import org.xq.wesign.bean.School;
import org.xq.wesign.bean.SchoolDepartmentLink;

import java.util.List;

@Mapper
public interface SchoolDao {
    int insertSchool(School school);

    School getSchoolById(String id);

    int updateSchool(School school);

    List<School> getAllSchool();

    List<School> getSchoolPage(RequestPage requestPage);

    int deleteSchool(String id);

}
