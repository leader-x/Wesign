package org.xq.wesign.service;

import org.xq.wesign.bean.Dict;
import org.xq.wesign.bean.RequestPage;

import java.util.List;

public interface DictService {
    void insertDict(Dict dict);

    Dict getDictById(String id);

    void updateDict(Dict dict);

    List<Dict> getDictPage(RequestPage requestPage);

    void deleteDict(String id);
}
