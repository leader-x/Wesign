package org.xq.wesign.dao;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;
import org.xq.wesign.bean.User;
import org.xq.wesign.bean.RequestPage;

import java.util.List;

@Mapper
public interface UserLoginDao {
    int insertUserLogin(User user);

    User getUserLoginById(String id);

    int updateUserLogin(User user);

    List<User> getAllUser();

    List<User> getUserPage(RequestPage requestPage);

    List<User> getAllUserLogin();

    List<User> getUserLoginPage(RequestPage requestPage);

    int deleteUserLogin(String id);

    User checkUserLogin(String userName,String password);

    User checkSameUsername(String userName);
}
