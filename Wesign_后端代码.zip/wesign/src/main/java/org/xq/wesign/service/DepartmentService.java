package org.xq.wesign.service;

import org.xq.wesign.bean.Department;
import org.xq.wesign.bean.RequestPage;

import java.util.List;

public interface DepartmentService {
    void insertDepartment(Department department);

    Department getDepartmentById(String id);

    void updateDepartment(Department department);

    List<Department> getDepartmentPage(RequestPage requestPage);

    void deleteDepartment(String id);
}
