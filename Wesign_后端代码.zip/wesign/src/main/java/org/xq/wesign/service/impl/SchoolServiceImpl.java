package org.xq.wesign.service.impl;

import com.alibaba.druid.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.xq.wesign.bean.Department;
import org.xq.wesign.bean.RequestPage;
import org.xq.wesign.bean.School;
import org.xq.wesign.bean.SchoolDepartmentLink;
import org.xq.wesign.dao.SchoolDao;
import org.xq.wesign.dao.SchoolDepartmentLinkDao;
import org.xq.wesign.exception.FriendException;
import org.xq.wesign.service.SchoolService;
import org.xq.wesign.utils.Util;

import java.util.List;
@Service
@Transactional
public class SchoolServiceImpl implements SchoolService {

    @Autowired
    private SchoolDao schoolDao;

    @Autowired
    private SchoolDepartmentLinkDao schoolDepartmentLinkDao;

    @Override
    public void insertSchool(School school) {
        if(school==null) {
            throw new FriendException("学校信息为空");
        }
        String schoolName=school.getSchoolName();
        String schoolCode=school.getSchoolCode();
        if(StringUtils.isEmpty(schoolName)||StringUtils.isEmpty(schoolCode)){
            throw new FriendException("学校信息不完整");
        }
        school.setSchoolId(Util.getUuid());
        schoolDao.insertSchool(school);
        List<Department> departmentList=school.getDepartmentList();
        if(departmentList!=null&&departmentList.size()!=0){
            for(Department department:departmentList){
                SchoolDepartmentLink schoolDepartmentLink=new SchoolDepartmentLink();
                schoolDepartmentLink.setDepartmentId(department.getDepartmentId());
                schoolDepartmentLink.setSchoolDepartmentLinkId(Util.getUuid());
                schoolDepartmentLink.setSchoolId(school.getSchoolId());
                schoolDepartmentLinkDao.insertSchoolDepartmentLink(schoolDepartmentLink);
            }
        }
    }

    @Override
    public School getSchoolById(String id) {
        if(StringUtils.isEmpty(id)){
            throw new FriendException("id不能为空");
        }else{
            School school=schoolDao.getSchoolById(id);
            if(school==null){
                throw new FriendException("不存在此学校信息");
            }else{
                return school;
            }
        }
    }

    @Override
    public void updateSchool(School school) {
        if(school==null) {
            throw new FriendException("学校信息为空");
        }
        String schoolId=school.getSchoolId();
        if(StringUtils.isEmpty(schoolId)){
            throw new FriendException("学校信息不完整");
        }
        List<Department> departmentList=school.getDepartmentList();
        if(departmentList!=null){
            schoolDepartmentLinkDao.deleteSchoolDepartmentLinkBySchoolId(schoolId);
            for(Department department:departmentList) {
                SchoolDepartmentLink schoolDepartmentLink=new SchoolDepartmentLink();
                schoolDepartmentLink.setSchoolDepartmentLinkId(Util.getUuid());
                schoolDepartmentLink.setDepartmentId(department.getDepartmentId());
                schoolDepartmentLink.setSchoolId(schoolId);
                schoolDepartmentLinkDao.insertSchoolDepartmentLink(schoolDepartmentLink);
            }
        }
        schoolDao.updateSchool(school);
    }

    @Override
    public List<School> getSchoolPage(RequestPage requestPage) {
        if(requestPage==null) {
            throw new FriendException("分页信息不能为空");
        }
        requestPage.setBeginPage((requestPage.getPage()-1)*requestPage.getPageSize());
        return schoolDao.getSchoolPage(requestPage);
    }

    @Override
    public void deleteSchool(String id) {
        if(StringUtils.isEmpty(id)){
            throw new FriendException("id不能为空");
        }else{
            schoolDao.deleteSchool(id);
            schoolDepartmentLinkDao.deleteSchoolDepartmentLinkBySchoolId(id);
        }
    }
}
