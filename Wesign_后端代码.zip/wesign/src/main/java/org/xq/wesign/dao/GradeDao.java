package org.xq.wesign.dao;

import org.apache.ibatis.annotations.Mapper;
import org.xq.wesign.bean.Grade;
import org.xq.wesign.bean.RequestPage;

import java.util.List;
@Mapper
public interface GradeDao {

    int insertGrade(Grade gxrade);

    Grade getGradeById(String id);

    int updateGrade(Grade grade);

    List<Grade> getAllGrade();

    List<Grade> getGradePage(RequestPage requestPage);

    int deleteGrade(String id);
}
