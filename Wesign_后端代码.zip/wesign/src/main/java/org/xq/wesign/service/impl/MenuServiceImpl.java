package org.xq.wesign.service.impl;

import com.alibaba.druid.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.xq.wesign.bean.Menu;
import org.xq.wesign.bean.RequestPage;
import org.xq.wesign.dao.MenuDao;
import org.xq.wesign.exception.FriendException;
import org.xq.wesign.service.MenuService;

import java.util.List;

@Service
@Transactional
public class MenuServiceImpl implements MenuService {

    @Autowired
    private MenuDao menuDao;

    @Override
    public void insertMenu(Menu menu) {
        if(menu==null) {
            throw new FriendException("菜单信息为空");
        }
        String menuName=menu.getMenuName();
        String url=menu.getUrl();
        if(StringUtils.isEmpty(menuName)||StringUtils.isEmpty(url)){
            throw new FriendException("菜单信息不完整");
        }
        menuDao.insertMenu(menu);
    }

    @Override
    public Menu getMenuById(int id) {
        Menu menu=menuDao.getMenuById(id);
        if(menu==null){
            throw new FriendException("不存在此菜单信息");
        }else{
            return menu;
        }
    }

    @Override
    public void updateMenu(Menu menu) {
        if(menu==null) {
            throw new FriendException("菜单信息为空");
        }
        int menuId=menu.getMenuId();
        if(menuId==0){
            throw new FriendException("菜单信息不完整");
        }
        menuDao.updateMenu(menu);
    }

    @Override
    public List<Menu> getMenuPage(RequestPage requestPage) {
        if(requestPage==null) {
            throw new FriendException("分页信息不能为空");
        }
        requestPage.setBeginPage((requestPage.getPage()-1)*requestPage.getPageSize());
        return menuDao.getMenuPage(requestPage);
    }

    @Override
    public void deleteMenu(int id) {
        menuDao.deleteMenu(id);
        menuDao.deleteMenuByParentId(id);
    }
}
