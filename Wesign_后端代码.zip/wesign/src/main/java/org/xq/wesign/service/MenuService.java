package org.xq.wesign.service;

import org.xq.wesign.bean.Menu;
import org.xq.wesign.bean.RequestPage;

import java.util.List;

public interface MenuService {
    void insertMenu(Menu menu);

    Menu getMenuById(int id);

    void updateMenu(Menu menu);

    List<Menu> getMenuPage(RequestPage requestPage);

    void deleteMenu(int id);
}
