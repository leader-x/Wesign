package org.xq.wesign.service;

import org.xq.wesign.bean.Course;
import org.xq.wesign.bean.RequestPage;

import java.util.List;

public interface CourseService {
    void insertCourse(Course course);

    Course getCourseById(String id);

    void updateCourse(Course course);

    List<Course> getCoursePage(RequestPage requestPage);

    void deleteCourse(String id);
}
