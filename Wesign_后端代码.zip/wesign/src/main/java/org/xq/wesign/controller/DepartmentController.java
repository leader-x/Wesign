package org.xq.wesign.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.xq.wesign.bean.Department;
import org.xq.wesign.bean.RequestPage;
import org.xq.wesign.enumeration.ResponseCode;
import org.xq.wesign.exception.FriendException;
import org.xq.wesign.other.ServerResponse;
import org.xq.wesign.service.DepartmentService;

import java.util.List;

@RestController
@RequestMapping("/department")
public class DepartmentController {

    @Autowired
    private DepartmentService departmentService;

    @PostMapping
    public ServerResponse insertDepartment(@RequestBody Department department){
        departmentService.insertDepartment(department);
        return new ServerResponse(ResponseCode.SUCCESS.getCode(),"院系信息插入成功");
    }

    @GetMapping("/{id}")
    public ServerResponse getDepartmentById(@PathVariable String id){
        Department department=departmentService.getDepartmentById(id);
        return new ServerResponse(ResponseCode.SUCCESS.getCode(),department,"院系信息查询成功");
    }

    @PutMapping
    public ServerResponse updateDepartment(@RequestBody Department department){
        departmentService.updateDepartment(department);
        return new ServerResponse(ResponseCode.SUCCESS.getCode(),"院系信息更新成功");
    }

    @GetMapping
    public ServerResponse getDepartmentPage(String page,String pageSize){
        try {
            RequestPage requestPage=new RequestPage(Integer.parseInt(page),Integer.parseInt(pageSize));
            List<Department> departmentList=departmentService.getDepartmentPage(requestPage);
            return new ServerResponse(ResponseCode.SUCCESS.getCode(),departmentList,"院系信息查询成功");
        }catch (Exception e){
            throw new FriendException("页数和页数大小必须是整数");
        }
    }

    @DeleteMapping("/{id}")
    public ServerResponse deleteDepartment(@PathVariable String id){
        departmentService.deleteDepartment(id);
        return new ServerResponse(ResponseCode.SUCCESS.getCode(),"院系信息删除成功");
    }
}
