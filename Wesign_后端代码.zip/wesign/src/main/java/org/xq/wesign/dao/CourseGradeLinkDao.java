package org.xq.wesign.dao;

import org.apache.ibatis.annotations.Mapper;
import org.xq.wesign.bean.CourseGradeLink;

@Mapper
public interface CourseGradeLinkDao {

    int insertCourseGradeLink(CourseGradeLink courseGradeLink);

    int updateCourseGradeLink(CourseGradeLink courseGradeLink);

    int deleteCourseGradeLink(String id);

    int deleteCourseGradeLinkByCourseId(String id);

    int deleteCourseGradeLinkByGradeId(String id);
}
