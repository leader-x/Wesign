package org.xq.wesign.service;

import org.xq.wesign.bean.RequestPage;
import org.xq.wesign.bean.User;

import java.util.List;

public interface UserInfoService {
    void insertUserInfo(User user);

    User getUserInfoById(String id);

    void updateUserInfo(User user);

    List<User> getUserInfoPage(RequestPage requestPage);

    void deleteUserInfo(String id);
}
