package org.xq.wesign.service;

import org.xq.wesign.bean.RequestPage;
import org.xq.wesign.bean.Schedule;

import java.util.List;

public interface ScheduleService {
    void insertSchedule(Schedule schedule);

    Schedule getScheduleById(String id);

    void updateSchedule(Schedule schedule);

    List<Schedule> getSchedulePage(RequestPage requestPage);

    void deleteSchedule(String id);
}
