package org.xq.wesign.dao;

import org.apache.ibatis.annotations.Mapper;
import org.xq.wesign.bean.RequestPage;
import org.xq.wesign.bean.Sign;

import java.util.List;

@Mapper
public interface SignDao {
    int insertSign(Sign sign);

    Sign getSignById(String id);

    int updateSign(Sign sign);

    List<Sign> getAllSign();

    List<Sign> getSignPage(RequestPage requestPage);

    int deleteSign(String id);
}
