package org.xq.wesign.bean;

public class SchoolDepartmentLink {
    private String schoolDepartmentLinkId;
    private String schoolId;
    private String departmentId;

    public String getSchoolDepartmentLinkId() {
        return schoolDepartmentLinkId;
    }

    public void setSchoolDepartmentLinkId(String schoolDepartmentLinkId) {
        this.schoolDepartmentLinkId = schoolDepartmentLinkId;
    }

    public String getSchoolId() {
        return schoolId;
    }

    public void setSchoolId(String schoolId) {
        this.schoolId = schoolId;
    }

    public String getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(String departmentId) {
        this.departmentId = departmentId;
    }
}
