package org.xq.wesign.service;


import org.xq.wesign.bean.RequestPage;
import org.xq.wesign.bean.Sign;

import java.util.List;

public interface SignService {
    void insertSign(Sign sign);

    Sign getSignById(String id);

    void updateSign(Sign sign);

    List<Sign> getSignPage(RequestPage requestPage);

    void deleteSign(String id);
}
