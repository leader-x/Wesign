package org.xq.wesign.service.impl;

import com.alibaba.druid.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.xq.wesign.bean.Course;
import org.xq.wesign.bean.CourseGradeLink;
import org.xq.wesign.bean.Grade;
import org.xq.wesign.bean.RequestPage;
import org.xq.wesign.dao.CourseDao;
import org.xq.wesign.dao.CourseGradeLinkDao;
import org.xq.wesign.exception.FriendException;
import org.xq.wesign.service.CourseService;
import org.xq.wesign.utils.Util;

import java.util.List;
@Service
@Transactional
public class CourseServiceImpl implements CourseService {

    @Autowired
    private CourseDao courseDao;

    @Autowired
    private CourseGradeLinkDao courseGradeLinkDao;

    @Override
    public void insertCourse(Course course) {
        if(course==null) {
            throw new FriendException("课程信息为空");
        }
        String courseName=course.getCourseName();
        String scheduleId=course.getScheduleId();
        String departmentId=course.getDepartmentId();
        String schoolId=course.getSchoolId();
        if(StringUtils.isEmpty(courseName)||StringUtils.isEmpty(scheduleId)||StringUtils.isEmpty(departmentId)||StringUtils.isEmpty(schoolId)){
            throw new FriendException("课程信息不完整");
        }
        course.setCourseId(Util.getUuid());
        courseDao.insertCourse(course);
        List<Grade> gradeList=course.getGradeList();
        if(gradeList!=null&&gradeList.size()!=0){
            for(Grade grade:gradeList){
                CourseGradeLink courseGradeLink=new CourseGradeLink();
                courseGradeLink.setCourseId(course.getCourseId());
                courseGradeLink.setCourseGradeLinkId(Util.getUuid());
                courseGradeLink.setGradeId(grade.getGradeId());
                courseGradeLinkDao.insertCourseGradeLink(courseGradeLink);
            }
        }
    }

    @Override
    public Course getCourseById(String id) {
        if(StringUtils.isEmpty(id)){
            throw new FriendException("id不能为空");
        }else{
            Course course=courseDao.getCourseById(id);
            if(course==null){
                throw new FriendException("不存在此课程信息");
            }else{
                return course;
            }
        }
    }

    @Override
    public void updateCourse(Course course) {
        if(course==null) {
            throw new FriendException("课程信息为空");
        }
        String courseId=course.getCourseId();
        String scheduleId=course.getScheduleId();
        String departmentId=course.getDepartmentId();
        String schoolId=course.getSchoolId();
        if(StringUtils.isEmpty(courseId)||StringUtils.isEmpty(scheduleId)||StringUtils.isEmpty(departmentId)||StringUtils.isEmpty(schoolId)){
            throw new FriendException("课程信息不完整");
        }
        List<Grade> gradeList=course.getGradeList();
        if(gradeList!=null){
            courseGradeLinkDao.deleteCourseGradeLinkByCourseId(courseId);
            for(Grade grade:gradeList) {
                CourseGradeLink courseGradeLink=new CourseGradeLink();
                courseGradeLink.setCourseGradeLinkId(Util.getUuid());
                courseGradeLink.setGradeId(grade.getGradeId());
                courseGradeLink.setCourseId(courseId);
                courseGradeLinkDao.insertCourseGradeLink(courseGradeLink);
            }
        }
        courseDao.updateCourse(course);
    }

    @Override
    public List<Course> getCoursePage(RequestPage requestPage) {
        if(requestPage==null) {
            throw new FriendException("分页信息不能为空");
        }
        requestPage.setBeginPage((requestPage.getPage()-1)*requestPage.getPageSize());
        return courseDao.getCoursePage(requestPage);
    }

    @Override
    public void deleteCourse(String id) {
        if(StringUtils.isEmpty(id)){
            throw new FriendException("id不能为空");
        }else{
            courseDao.deleteCourse(id);
            courseGradeLinkDao.deleteCourseGradeLinkByCourseId(id);
        }
    }
}
