package org.xq.wesign.dao;

import org.apache.ibatis.annotations.Mapper;
import org.xq.wesign.bean.Menu;
import org.xq.wesign.bean.RequestPage;

import java.util.List;
@Mapper
public interface MenuDao {
    int insertMenu(Menu menu);

    Menu getMenuById(int id);

    int updateMenu(Menu menu);

    List<Menu> getAllMenu();

    List<Menu> getMenuPage(RequestPage requestPage);

    int deleteMenu(int id);

    int deleteMenuByParentId(int id);
}
