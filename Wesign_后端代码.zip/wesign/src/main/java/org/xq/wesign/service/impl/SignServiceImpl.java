package org.xq.wesign.service.impl;

import com.alibaba.druid.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.xq.wesign.bean.RequestPage;
import org.xq.wesign.bean.Sign;
import org.xq.wesign.dao.SignDao;
import org.xq.wesign.exception.FriendException;
import org.xq.wesign.service.SignService;

import java.util.Date;
import java.util.List;

@Service
@Transactional
public class SignServiceImpl implements SignService {

    @Autowired
    private SignDao signDao;

    @Override
    public void insertSign(Sign sign) {
        if(sign==null) {
            throw new FriendException("签到信息为空");
        }
        String userInfoId=sign.getUserInfoId();
        String courseId =sign.getCourseId();
        String msg=sign.getMsg();
        if(StringUtils.isEmpty(userInfoId)||StringUtils.isEmpty(courseId)||StringUtils.isEmpty(msg)){
            throw new FriendException("签到信息不完整");
        }
        signDao.insertSign(sign);
    }

    @Override
    public Sign getSignById(String id) {
        Sign sign=signDao.getSignById(id);
        if(sign==null){
            throw new FriendException("不存在此签到信息");
        }else{
            return sign;
        }
    }

    @Override
    public void updateSign(Sign sign) {
        if(sign==null) {
            throw new FriendException("签到信息为空");
        }
        String courseId=sign.getCourseId();
        String gradeId=sign.getGradeId();
        String signId=sign.getSignId();
        if(StringUtils.isEmpty(courseId)||StringUtils.isEmpty(gradeId)||StringUtils.isEmpty(signId)){
            throw new FriendException("签到信息不完整");
        }
        signDao.updateSign(sign);
    }

    @Override
    public List<Sign> getSignPage(RequestPage requestPage) {
        if(requestPage==null) {
            throw new FriendException("分页信息不能为空");
        }
        requestPage.setBeginPage((requestPage.getPage()-1)*requestPage.getPageSize());
        return signDao.getSignPage(requestPage);
    }

    @Override
    public void deleteSign(String id) {
        if(StringUtils.isEmpty(id)){
            throw new FriendException("id不能为空");
        }else{
            signDao.deleteSign(id);
        }
    }
}
