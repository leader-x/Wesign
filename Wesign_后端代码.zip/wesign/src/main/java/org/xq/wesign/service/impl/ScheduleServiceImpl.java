package org.xq.wesign.service.impl;

import com.alibaba.druid.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.xq.wesign.bean.RequestPage;
import org.xq.wesign.bean.Schedule;
import org.xq.wesign.bean.School;
import org.xq.wesign.dao.ScheduleDao;
import org.xq.wesign.dao.SchoolDao;
import org.xq.wesign.exception.FriendException;
import org.xq.wesign.service.ScheduleService;
import org.xq.wesign.service.SchoolService;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
@Service
@Transactional
public class ScheduleServiceImpl implements ScheduleService {

    @Autowired
    private ScheduleDao scheduleDao;

    @Override
    public void insertSchedule(Schedule schedule) {
        if(schedule==null) {
            throw new FriendException("时间表信息为空");
        }
        String term=schedule.getTerm();
        Date beginTime =schedule.getBeginTime();
        Date endTime =schedule.getEndTime();
        if(StringUtils.isEmpty(term)||beginTime==null||endTime==null){
            throw new FriendException("时间表不完整");
        }
        scheduleDao.insertSchedule(schedule);
    }

    @Override
    public Schedule getScheduleById(String id) {
        Schedule schedule=scheduleDao.getScheduleById(id);
        if(schedule==null){
            throw new FriendException("不存在此时间表信息");
        }else{
            return schedule;
        }
    }

    @Override
    public void updateSchedule(Schedule schedule) {
        if(schedule==null) {
            throw new FriendException("时间表信息为空");
        }
        String scheduleId=schedule.getScheduleId();
        if(StringUtils.isEmpty(scheduleId)){
            throw new FriendException("时间表不完整");
        }
        scheduleDao.updateSchedule(schedule);
    }

    @Override
    public List<Schedule> getSchedulePage(RequestPage requestPage) {
        if(requestPage==null) {
            throw new FriendException("分页信息不能为空");
        }
        requestPage.setBeginPage((requestPage.getPage()-1)*requestPage.getPageSize());
        return scheduleDao.getSchedulePage(requestPage);
    }

    @Override
    public void deleteSchedule(String id) {
        scheduleDao.deleteSchedule(id);
    }
}
