package org.xq.wesign.service.impl;

import com.alibaba.druid.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.xq.wesign.bean.Department;
import org.xq.wesign.bean.RequestPage;
import org.xq.wesign.bean.School;
import org.xq.wesign.bean.SchoolDepartmentLink;
import org.xq.wesign.dao.DepartmentDao;
import org.xq.wesign.dao.SchoolDao;
import org.xq.wesign.dao.SchoolDepartmentLinkDao;
import org.xq.wesign.exception.FriendException;
import org.xq.wesign.service.DepartmentService;
import org.xq.wesign.utils.Util;

import java.util.List;

@Service
@Transactional
public class DepartmentServiceImpl implements DepartmentService {

    @Autowired
    private DepartmentDao departmentDao;

    @Autowired
    private SchoolDepartmentLinkDao schoolDepartmentLinkDao;

    @Override
    public void insertDepartment(Department department) {
        if(department==null) {
            throw new FriendException("院系信息为空");
        }
        String departmentName=department.getDepartmentName();
        if(StringUtils.isEmpty(departmentName)){
            throw new FriendException("院系信息不完整");
        }
        department.setDepartmentId(Util.getUuid());
        departmentDao.insertDepartment(department);
        List<School> schoolList=department.getSchoolList();
        if(schoolList!=null&&schoolList.size()!=0){
            for(School school:schoolList){
                SchoolDepartmentLink schoolDepartmentLink=new SchoolDepartmentLink();
                schoolDepartmentLink.setDepartmentId(department.getDepartmentId());
                schoolDepartmentLink.setSchoolDepartmentLinkId(Util.getUuid());
                schoolDepartmentLink.setSchoolId(school.getSchoolId());
                schoolDepartmentLinkDao.insertSchoolDepartmentLink(schoolDepartmentLink);
            }
        }
    }

    @Override
    public Department getDepartmentById(String id) {
        if(StringUtils.isEmpty(id)){
            throw new FriendException("id不能为空");
        }else{
            Department department=departmentDao.getDepartmentById(id);
            if(department==null){
                throw new FriendException("不存在此院系信息");
            }else{
                return department;
            }
        }
    }

    @Override
    public void updateDepartment(Department department) {
        if(department==null) {
            throw new FriendException("院系信息为空");
        }
        String departmentId=department.getDepartmentId();
        if(StringUtils.isEmpty(departmentId)){
            throw new FriendException("院系信息不完整");
        }
        List<School> schoolList=department.getSchoolList();
        if(schoolList!=null){
            schoolDepartmentLinkDao.deleteSchoolDepartmentLinkByDepartmentId(departmentId);
            for(School school:schoolList) {
                SchoolDepartmentLink schoolDepartmentLink=new SchoolDepartmentLink();
                schoolDepartmentLink.setSchoolDepartmentLinkId(Util.getUuid());
                schoolDepartmentLink.setDepartmentId(departmentId);
                schoolDepartmentLink.setSchoolId(school.getSchoolId());
                schoolDepartmentLinkDao.insertSchoolDepartmentLink(schoolDepartmentLink);
            }
        }
        departmentDao.updateDepartment(department);
    }

    @Override
    public List<Department> getDepartmentPage(RequestPage requestPage) {
        if(requestPage==null) {
            throw new FriendException("分页信息不能为空");
        }
        requestPage.setBeginPage((requestPage.getPage()-1)*requestPage.getPageSize());
        return departmentDao.getDepartmentPage(requestPage);
    }

    @Override
    public void deleteDepartment(String id) {
        if(StringUtils.isEmpty(id)){
            throw new FriendException("id不能为空");
        }else{
            departmentDao.deleteDepartment(id);
            schoolDepartmentLinkDao.deleteSchoolDepartmentLinkByDepartmentId(id);
        }
    }
}
