package org.xq.wesign.service;

import org.xq.wesign.bean.RequestPage;
import org.xq.wesign.bean.User;
import org.xq.wesign.exception.FriendException;

import java.util.List;

public interface UserLoginService {

    void insertUserLogin(User user);

    User getUserLoginById(String id);

    void updateUserLogin(User user);

    List<User> getUserPage(RequestPage requestPage);

    void deleteUserLogin(String id);

    User checkUserLogin(User user);
}
