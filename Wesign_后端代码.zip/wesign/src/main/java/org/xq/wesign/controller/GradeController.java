package org.xq.wesign.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.xq.wesign.bean.Grade;
import org.xq.wesign.bean.RequestPage;
import org.xq.wesign.enumeration.ResponseCode;
import org.xq.wesign.exception.FriendException;
import org.xq.wesign.other.ServerResponse;
import org.xq.wesign.service.GradeService;

import java.util.List;

@RestController
@RequestMapping("/grade")
public class GradeController {

    @Autowired
    private GradeService gradeService;

    @PostMapping
    public ServerResponse insertGrade(@RequestBody Grade grade){
        gradeService.insertGrade(grade);
        return new ServerResponse(ResponseCode.SUCCESS.getCode(),"班级信息插入成功");
    }

    @GetMapping("/{id}")
    public ServerResponse getGradeById(@PathVariable String id){
        Grade grade=gradeService.getGradeById(id);
        return new ServerResponse(ResponseCode.SUCCESS.getCode(),grade,"班级信息查询成功");
    }

    @PutMapping
    public ServerResponse updateGrade(@RequestBody Grade grade){
        gradeService.updateGrade(grade);
        return new ServerResponse(ResponseCode.SUCCESS.getCode(),"班级信息更新成功");
    }

    @GetMapping
    public ServerResponse getGradePage(String page,String pageSize){
        try {
            RequestPage requestPage=new RequestPage(Integer.parseInt(page),Integer.parseInt(pageSize));
            List<Grade> gradeList=gradeService.getGradePage(requestPage);
            return new ServerResponse(ResponseCode.SUCCESS.getCode(),gradeList,"班级信息查询成功");
        }catch (Exception e){
            throw new FriendException("页数和页数大小必须是整数");
        }
    }

    @DeleteMapping("/{id}")
    public ServerResponse deleteGrade(@PathVariable String id){
        gradeService.deleteGrade(id);
        return new ServerResponse(ResponseCode.SUCCESS.getCode(),"班级信息删除成功");
    }
}
