package org.xq.wesign.dao;

import org.apache.ibatis.annotations.Mapper;
import org.xq.wesign.bean.Course;
import org.xq.wesign.bean.RequestPage;

import java.util.List;
@Mapper
public interface CourseDao {
    int insertCourse(Course course);

    Course getCourseById(String id);

    int updateCourse(Course course);

    List<Course> getAllCourse();

    List<Course> getCoursePage(RequestPage requestPage);

    int deleteCourse(String id);
}
