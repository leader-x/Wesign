package org.xq.wesign.test;

public class MessageServiceImpl implements MessageService{
    @Override
    public String getMessage() {
        return "hello world";
    }
}
