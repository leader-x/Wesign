package org.xq.wesign.config;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.xq.wesign.enumeration.ResponseCode;
import org.xq.wesign.exception.FriendException;
import org.xq.wesign.other.ServerResponse;

@ControllerAdvice
public class MyExceptionHandler {

    @ResponseBody
    @ExceptionHandler(FriendException.class)
    public ServerResponse handlerException(Exception e){
        return new ServerResponse(ResponseCode.ERROR.getCode(),e.getMessage());
    }
}
