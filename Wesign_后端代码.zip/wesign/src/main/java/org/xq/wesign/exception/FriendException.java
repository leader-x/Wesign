package org.xq.wesign.exception;

public class FriendException extends RuntimeException{

    public FriendException(String msg){
        super(msg);
    }
}
