package org.xq.wesign;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WesignApplication {

    public static void main(String[] args) {
        SpringApplication.run(WesignApplication.class, args);
    }

}
