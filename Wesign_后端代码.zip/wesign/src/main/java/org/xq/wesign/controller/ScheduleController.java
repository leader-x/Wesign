package org.xq.wesign.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.xq.wesign.bean.RequestPage;
import org.xq.wesign.bean.Schedule;
import org.xq.wesign.enumeration.ResponseCode;
import org.xq.wesign.exception.FriendException;
import org.xq.wesign.other.ServerResponse;
import org.xq.wesign.service.ScheduleService;

import java.util.List;

@RestController
@RequestMapping("/schedule")
public class ScheduleController {

    @Autowired
    private ScheduleService scheduleService;

    @PostMapping
    public ServerResponse insertSchedule(@RequestBody Schedule schedule){
        System.out.println("==========");
        scheduleService.insertSchedule(schedule);
        return new ServerResponse(ResponseCode.SUCCESS.getCode(),"时间表信息插入成功");
    }

    @GetMapping("/{id}")
    public ServerResponse getScheduleById(@PathVariable String id){
        Schedule schedule=scheduleService.getScheduleById(id);
        return new ServerResponse(ResponseCode.SUCCESS.getCode(),schedule,"时间表信息查询成功");
    }

    @PutMapping
    public ServerResponse updateSchedule(@RequestBody Schedule schedule){
        scheduleService.updateSchedule(schedule);
        return new ServerResponse(ResponseCode.SUCCESS.getCode(),"时间表信息更新成功");
    }

    @GetMapping
    public ServerResponse getSchedulePage(String page,String pageSize){
        try {
            RequestPage requestPage=new RequestPage(Integer.parseInt(page),Integer.parseInt(pageSize));
            List<Schedule> scheduleList=scheduleService.getSchedulePage(requestPage);
            return new ServerResponse(ResponseCode.SUCCESS.getCode(),scheduleList,"时间表信息查询成功");
        }catch (Exception e){
            throw new FriendException("页数和页数大小必须是整数");
        }
    }

    @DeleteMapping("/{id}")
    public ServerResponse deleteSchedule(@PathVariable String id){
        scheduleService.deleteSchedule(id);
        return new ServerResponse(ResponseCode.SUCCESS.getCode(),"时间表信息删除成功");
    }
}
