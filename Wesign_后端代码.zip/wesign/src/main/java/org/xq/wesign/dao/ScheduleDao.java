package org.xq.wesign.dao;

import org.apache.ibatis.annotations.Mapper;
import org.xq.wesign.bean.RequestPage;
import org.xq.wesign.bean.Schedule;

import java.util.List;

@Mapper
public interface ScheduleDao {

    int insertSchedule(Schedule schedule);

    Schedule getScheduleById(String id);

    int updateSchedule(Schedule schedule);

    List<Schedule> getAllSchedule();

    List<Schedule> getSchedulePage(RequestPage requestPage);

    int deleteSchedule(String id);
}
