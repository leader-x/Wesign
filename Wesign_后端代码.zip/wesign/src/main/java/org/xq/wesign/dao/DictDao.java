package org.xq.wesign.dao;

import org.apache.ibatis.annotations.Mapper;
import org.xq.wesign.bean.Dict;
import org.xq.wesign.bean.RequestPage;

import java.util.List;

@Mapper
public interface DictDao {
    int insertDict(Dict dict);

    Dict getDictById(String id);

    int updateDict(Dict dict);

    List<Dict> getAllDict();

    List<Dict> getDictPage(RequestPage requestPage);

    int deleteDict(String id);

}
