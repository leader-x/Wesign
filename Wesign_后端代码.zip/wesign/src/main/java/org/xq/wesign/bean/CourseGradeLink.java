package org.xq.wesign.bean;

public class CourseGradeLink {

    private String courseGradeLinkId;
    private String gradeId;
    private String courseId;

    public String getCourseGradeLinkId() {
        return courseGradeLinkId;
    }

    public void setCourseGradeLinkId(String courseGradeLinkId) {
        this.courseGradeLinkId = courseGradeLinkId;
    }

    public String getGradeId() {
        return gradeId;
    }

    public void setGradeId(String gradeId) {
        this.gradeId = gradeId;
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }
}
