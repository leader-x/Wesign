package org.xq.wesign.service.impl;

import com.alibaba.druid.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.xq.wesign.bean.RequestPage;
import org.xq.wesign.bean.User;
import org.xq.wesign.dao.UserLoginDao;
import org.xq.wesign.exception.FriendException;
import org.xq.wesign.service.UserLoginService;
import org.xq.wesign.utils.Util;

import java.util.List;

@Service
@Transactional
public class UserLoginServiceImpl implements UserLoginService {

    @Autowired
    private UserLoginDao userLoginDao;

    @Override
    public void insertUserLogin(User user) {
        if(user==null) {
            throw new FriendException("用户登录信息为空");
        }
        String userName=user.getUserName();
        String password=user.getPassword();
        String userInfoId=user.getUserInfoId();
        if(StringUtils.isEmpty(userName)||StringUtils.isEmpty(password)||StringUtils.isEmpty(userInfoId)) {
            throw new FriendException("用户登录信息不完整");
        }
        User isSameUsername=userLoginDao.checkSameUsername(userName);
        if(isSameUsername!=null) {
            throw new FriendException("用户名重复");
        }
        user.setUserId(Util.getUuid());
        userLoginDao.insertUserLogin(user);
    }

    @Override
    public User getUserLoginById(String id) {
        if(StringUtils.isEmpty(id)){
            throw new FriendException("id不能为空");
        }else{
            User user=userLoginDao.getUserLoginById(id);
            if(user==null){
                throw new FriendException("不存在此用户登录信息");
            }else{
                return user;
            }
        }
    }

    @Override
    public void updateUserLogin(User user) {
        if(user==null) {
            throw new FriendException("用户登录信息为空");
        }
        String userId=user.getUserId();
        if(StringUtils.isEmpty(userId)){
            throw new FriendException("用户登录信息不完整");
        }
        String userName=user.getUserName();
        if(!StringUtils.isEmpty(userName)){
            User selectUser=userLoginDao.getUserLoginById(userId);
            if(!userName.equals(selectUser.getUserName())){
                //修改了用户名
                User isSameUsername=userLoginDao.checkSameUsername(userName);
                if(isSameUsername!=null) {
                    throw new FriendException("用户名重复");
                }
            }
        }
        userLoginDao.updateUserLogin(user);
    }

    @Override
    public List<User> getUserPage(RequestPage requestPage) {
        if(requestPage==null) {
            throw new FriendException("分页信息不能为空");
        }
        requestPage.setBeginPage((requestPage.getPage()-1)*requestPage.getPageSize());
        return userLoginDao.getUserPage(requestPage);
    }

    @Override
    public void deleteUserLogin(String id) {
        if(StringUtils.isEmpty(id)){
            throw new FriendException("id不能为空");
        }else{
            userLoginDao.deleteUserLogin(id);
        }
    }

    @Override
    public User checkUserLogin(User user) {
        if(user==null) {
            throw new FriendException("用户登录信息为空");
        }
        String userName=user.getUserName();
        String password=user.getPassword();
        if(StringUtils.isEmpty(userName)||StringUtils.isEmpty(password)) {
            throw new FriendException("用户名或密码为空");
        }
        User loginUser=userLoginDao.checkUserLogin(userName,password);
        if(loginUser!=null){
            return loginUser;
        }else {
            throw new FriendException("用户名或密码错误");
        }
    }


}
