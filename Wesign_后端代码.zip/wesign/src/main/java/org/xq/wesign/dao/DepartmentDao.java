package org.xq.wesign.dao;

import org.apache.ibatis.annotations.Mapper;
import org.xq.wesign.bean.Department;
import org.xq.wesign.bean.RequestPage;

import java.util.List;

@Mapper
public interface DepartmentDao {
    int insertDepartment(Department department);

    Department getDepartmentById(String id);

    int updateDepartment(Department department);

    List<Department> getAllDepartment();

    List<Department> getDepartmentPage(RequestPage requestPage);

    int deleteDepartment(String id);

}
