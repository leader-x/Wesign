package org.xq.wesign.service;

import org.xq.wesign.bean.RequestPage;
import org.xq.wesign.bean.School;

import java.util.List;

public interface SchoolService {
    void insertSchool(School school);

    School getSchoolById(String id);

    void updateSchool(School school);

    List<School> getSchoolPage(RequestPage requestPage);

    void deleteSchool(String id);
}
