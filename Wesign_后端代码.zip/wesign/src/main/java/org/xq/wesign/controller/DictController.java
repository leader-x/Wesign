package org.xq.wesign.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.xq.wesign.bean.Dict;
import org.xq.wesign.bean.RequestPage;
import org.xq.wesign.enumeration.ResponseCode;
import org.xq.wesign.exception.FriendException;
import org.xq.wesign.other.ServerResponse;
import org.xq.wesign.service.DictService;

import java.util.List;

@RestController
@RequestMapping("/dict")
public class DictController {

    @Autowired
    private DictService dictService;

    @PostMapping
    public ServerResponse insertDict(@RequestBody Dict dict){
        dictService.insertDict(dict);
        return new ServerResponse(ResponseCode.SUCCESS.getCode(),"数据字典信息插入成功");
    }

    @GetMapping("/{id}")
    public ServerResponse getDictById(@PathVariable String id){
        Dict dict=dictService.getDictById(id);
        return new ServerResponse(ResponseCode.SUCCESS.getCode(),dict,"数据字典信息查询成功");
    }

    @PutMapping
    public ServerResponse updateDict(@RequestBody Dict dict){
        dictService.updateDict(dict);
        return new ServerResponse(ResponseCode.SUCCESS.getCode(),"数据字典信息更新成功");
    }

    @GetMapping
    public ServerResponse getDictPage(String page,String pageSize){
        try{
            RequestPage requestPage=new RequestPage(Integer.parseInt(page),Integer.parseInt(pageSize));
            List<Dict> dictList=dictService.getDictPage(requestPage);
            return new ServerResponse(ResponseCode.SUCCESS.getCode(),dictList,"数据字典信息查询成功");
        }catch (Exception e){
            throw new FriendException("页数和页数大小必须是整数");
        }
    }

    @DeleteMapping("/{id}")
    public ServerResponse deleteDict(@PathVariable String id){
        dictService.deleteDict(id);
        return new ServerResponse(ResponseCode.SUCCESS.getCode(),"数据字典信息删除成功");
    }

}
