package org.xq.wesign.dao;

import org.apache.ibatis.annotations.Mapper;
import org.xq.wesign.bean.RequestPage;
import org.xq.wesign.bean.User;

import java.util.List;

@Mapper
public interface UserInfoDao {
    int insertUserInfo(User user);

    User getUserInfoById(String id);

    int updateUserInfo(User user);

    List<User> getAllUserInfo();

    List<User> getUserInfoPage(RequestPage requestPage);

    int deleteUserInfo(String id);
}
