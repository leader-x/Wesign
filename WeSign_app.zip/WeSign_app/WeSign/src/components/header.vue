<template>
  <div id="nvheader">
    <link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
    <mt-header title="微签">
      <router-link to="/" slot="left">
        <mt-button icon="back">返回</mt-button>
      </router-link>
      <!--<mt-search-->
        <!--v-model="value"-->
        <!--cancel-text="取消"-->
        <!--placeholder="搜索">-->
      <!--</mt-search>-->
      <div class="page-actionsheet-wrapper" slot="right">
        <button class="mint-button mint-button--default mint-button--large"  @click="actionSheet">
          <svg class="icon icon-add-solid" slot="right"><use xlink:href="#icon-add-solid"></use></svg>
        </button>
        <mt-actionsheet
          :actions="actions"
          v-model="sheetVisible" cancel-text="">
        </mt-actionsheet>
      </div>
    </mt-header>
  </div>
</template>

<script type="text/ecmascript-6">

  export default {
    data() {
      return {
        value: '',
        actions:[],
        sheetVisible:false,
      }
    },
    mounted(){
      this.actions = [{
        name: '创建班课',
        method: this.createClass
      },{
        name: '使用班课号加入班课',
        method: this.joinClass
      }];
    },
    methods:{
      more(){
        console.log('more');
      },
      main_log(val) {
        console.log('main_log', val);
      },
      sub_log(val) {
        console.log('sub_log', val);
        this.$refs.target_1.collapse();
      },
      actionSheet(){
        this.sheetVisible = true;
      },
      createClass(){
        console.log('create');
        this.$router.push('/createClass');
//        this.sheetVisible = true;
      },
      joinClass(){
        console.log('join');
        this.$router.push('/joinClass');
      },
    }
  }
</script>
<style scoped>
  #nvheader .mint-header{
    background-color: #e91e63;
    height: 5%;
    width: 100%;
    margin: 0px;
    position: fixed;
    /*margin-left: -10px;*/
  }
  .icon {
    display: inline-block;
    width: 1.5em;
    height: 1.5em;
    stroke-width: 0;
    stroke: currentColor;
    fill: currentColor;
  }
  .page-actionsheet-wrapper{
    /*background-color: #e91e63;*/
    /*padding: 0 20px;*/
    /*position: relative;*/
    /*width: 100%;*/
    margin: 0px 0px 0px 75px;
    /*transform: translateY(-50%);*/
  }
  .mint-actionsheet{
    /*background-color: #42b983;*/
    margin: 0px 0px 33px 0px;
  }

</style>
