<template>
  <div>
    <footer id="navfooter">
      <!-- tab-container -->
      <mt-tab-container v-model="selected1">
        <mt-tab-container-item id="first">
          <div class="page-search">
            <form action="" target="frameFile">
              <mt-search v-model="searchValue">
                <mt-cell
                  v-for="(item,index) in searchResult" :key="index"
                  :title="item.title"
                  :value="item.value"
                  @keyup.enter.native="search">
                  <iframe name="frameFile" style="display: none;"></iframe>
                </mt-cell>
              </mt-search>
            </form>
          </div>
        </mt-tab-container-item>
        <mt-tab-container-item id="second">
          <mt-cell v-for="(item,index) in classList" :key="index" :title="item.courseName" is-link
                   :to="{path:'classDetail',query:{className:item.className,courseName:item.courseName}}">
            <!--to="/classDetail">-->
            <!--<img slot="icon" src="../../static/images/code_img.png"/>-->
          </mt-cell>
        </mt-tab-container-item>
        <mt-tab-container-item id="third">
          <mt-cell title="课程圈" is-link  />
          <mt-cell title="附近的人" is-link />
        </mt-tab-container-item>
        <mt-tab-container-item id="forth">
          <mt-cell :title="user" style="height: 150px" is-link>
            <br/><span>海纳百川<br/>有容乃大</span>
            <img slot="icon" src="/static/images/user-photo.png" style="margin: 10px"/>
          </mt-cell>
          <mt-cell style="margin: 10px 70px 0 0px;">
            <img slot="icon" src="/static/images/icon-qqkongjian.png" style="margin: 10px 10px 10px 10px;"/>
            <img slot="icon" src="/static/images/icon-collections.png" style="margin: 10px 10px 10px 10px;"/>
            <img slot="icon" src="/static/images/icon-xunzhang.png" style="margin: 10px 10px 10px 10px;"/>
          </mt-cell>
          <mt-cell title="设置" style="margin: 10px 0px 40px 0px;text-align: left" is-link to="/setting">
            <img slot="icon" src="/static/images/icon-setting.png"
                 style="margin: 5px 10px 5px 20px;"/>
          </mt-cell>
        </mt-tab-container-item>
      </mt-tab-container>

      <mt-tabbar v-model="message" style="flex: auto; height: 100%">
        <mt-tab-item id="first">
          <svg-icon icon-class="table" style="font-size: 14px"></svg-icon>
          <span style="font-size: 16px">首页</span>
        </mt-tab-item>
        <mt-tab-item id="second">
          <svg-icon icon-class="dashboard" style="font-size: 16px"></svg-icon>
          <span style="font-size: 16px">班级</span>
        </mt-tab-item>
        <mt-tab-item id="third">
          <svg-icon icon-class="example" style="font-size: 16px"></svg-icon>
          <span style="font-size: 16px">发现</span>
        </mt-tab-item>
        <mt-tab-item id="forth">
          <svg-icon icon-class="user" style="font-size: 18px" v-bind:class="{'on':selected=='forth'}"></svg-icon>
          <span style="font-size: 16px">我的</span>
        </mt-tab-item>
      </mt-tabbar>
    </footer>
  </div>
</template>

<script type="text/ecmascript-6">
  import axios from 'axios'

  export default {
    data() {
      return {
        message:'',
        user: '',
        selected1: '',
        classList: [],
        searchValue:'',
        searchResult:[],
      }
    },
    props:{
      selected: String,
    },
    watch:{
      message(val,oldVal){
        console.log(val);
        switch(val){
          case 'first':
            this.selected1="first";
//            this.$router.push("/home?selected=first");
            break;
          case 'second':
            this.selected1="second";
//            this.$router.push("/home?selected=second");
            break;
          case 'third':
            this.selected1="third";
//            this.$router.push("/home?selected=third");
            break;
          case 'forth':
            this.selected1="forth";
//            this.$router.push("/home?selected=forth");
            break;
        }
      },
//      '$route': 'getParams'
    },
    created() {
//      activeRoute () {
//        return this.$route.path
//      }
      this.getParams();
    },
    mounted(){
      this.user = JSON.parse(localStorage.getItem('userInfo')).userName
//      console.log(this.user)
      this.init();
    },
    methods: {
      init(){
        var params = {
        }
        axios.get("/grades",{
          params:params
        }).then((result)=>{
          var res = result.data;
          console.log(res);
          if(res.status =='0'){
            this.classList = res.result.list;
            console.log(this.classList);
          }else {
            this.classList = null;
            console.log(this.classList);
          }
        });

//        axios.get("139.199.79.80:8080/course", {
//
//        })
      },
      search(){
        if(this.searchValue.length != 0){
          //todo
          this.$router.push({name:'search',query:{value:this.searchValue}});
        }
      },
      getParams(){
        var routerParam = this.$route.query.selected;
        console.log('selected:'+this.selected,'param:'+routerParam);
        if(typeof routerParam != 'undefined')
          this.selected1 = routerParam;
        else
          this.selected1 = 'first';
      },

    }
  }
</script>
<style scoped>
  /*footer部分*/
  #navfooter{
    width: 100%;
    height: 40px;
    background:white;
    left: 0;
    right: 0;
    position: fixed;
    bottom: 0;
    margin: 0px;
  }
  .mint-tab-container{
    /*background-color: #e91e63;*/
    width: 100%;
    height: auto;
    /*margin: -663px; 565*/
    top: -570px;
   /*margin: -740px 0px 0px 0px;*/
  }
  /*.mint-tab-container-item{*/
    /*background-color: blue;*/
    /*width: 100%;*/
    /*height: auto;*/
    /*top: 10%;*/
  /*}*/
  .mint-cell{
    /* f5f7f9*/
    background-color: #FEC171;
    width: 100%;
    top: 0px;
    left: 0;
    right: 0;
    position: relative;
    /*margin-top: 10px;*/
    /*margin: 10px 0px 0 0px;*/
  }
  .page-search {
    height: 100%;
    width: 50%;
    /*background-color: #dc3958;*/
    margin: 0px 0px 0 700px;
  }
  /*.mt-search{*/
    /*!*margin: 0px 10px 0 10px;*!*/
    /*!*position: relative;*!*/
  /*}*/
  .mint-search{
    margin: 0 485px 0 -35px;
  }
  .on{
    fill: #dc3958;
  }
</style>
