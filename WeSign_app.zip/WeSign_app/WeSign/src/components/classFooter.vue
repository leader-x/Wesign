<template>
  <footer id="footer">
    <div class="content">
      <mt-tab-container v-model="selected">
        <mt-tab-container-item id="first">
          <div class="page-source">
            <p>老师还没有上传资源</p>
          </div>
        </mt-tab-container-item>
        <mt-tab-container-item id="second">
          <div class="student">
            <svg-icon icon-class="alarm"></svg-icon><br/>
            <span @click="gotoSign()" v-show="role=='2'">参与签到</span>
            <span @click="gotoSign()" v-show="role=='1'">发起签到</span>
            <label>成员总数{{studentList.length}}人</label>
            <mt-cell v-for="(item,index) in studentList" :title="item.id+' '+item.name" :key="index"></mt-cell>
          </div>
        </mt-tab-container-item>
        <mt-tab-container-item id="third">
          <div class="activNavbar">
            <mt-navbar  v-model="selectActiv">
              <mt-tab-item id="1">全部{{activTotal.length}}</mt-tab-item>
              <mt-tab-item id="2">进行中{{ongoing.length}}</mt-tab-item>
              <mt-tab-item id="3">已结束{{end.length}}</mt-tab-item>
            </mt-navbar>
            <!-- tab-container -->
            <mt-tab-container class="activContainer" v-model="selectActiv">
              <mt-tab-container-item id="1">
                <mt-cell v-for="(item,index) in activTotal" :key="index" :title="item" />
              </mt-tab-container-item>
              <mt-tab-container-item id="2">
                <mt-cell v-for="(item,index) in ongoing" :key="index" :title="item" />
              </mt-tab-container-item>
              <mt-tab-container-item id="3">
                <mt-cell v-for="(item,index) in end" :key="index" :title="item" />
              </mt-tab-container-item>
            </mt-tab-container>
          </div>
        </mt-tab-container-item>
        <mt-tab-container-item id="forth">
          <mt-cell  title="班课通知" is-link to="/classNotice"></mt-cell>
        </mt-tab-container-item>
      </mt-tab-container>
    </div>

    <div class="tabbar">
      <mt-tabbar v-model="selected" style="flex: auto; height: 100%">
        <mt-tab-item id="first">
          <svg-icon icon-class="table" style="font-size: 14px"></svg-icon>
          <span style="font-size: 16px">资源</span>
        </mt-tab-item>
        <mt-tab-item id="second">
          <svg-icon icon-class="peoples" style="font-size: 16px"></svg-icon>
          <span style="font-size: 16px">成员</span>
        </mt-tab-item>
        <mt-tab-item id="third">
          <svg-icon icon-class="nested" style="font-size: 16px"></svg-icon>
          <span style="font-size: 16px">活动</span>
        </mt-tab-item>
        <mt-tab-item id="forth">
          <svg-icon icon-class="message" style="font-size: 18px"></svg-icon>
          <span style="font-size: 16px">消息</span>
        </mt-tab-item>
      </mt-tabbar>
    </div>

  </footer>
</template>

<script type="text/ecmascript-6">

  import axios from 'axios'
//  const axiosInstance = axios.create({
//    headers: {'Content-Type': 'application/json;charset=utf-8'}, // 设置传输内容和编码
//    withCredentials: true, // 指定某个请求应该发送数据
//  });
  export default {
    props:{
      selectedBar: '',
    },
    data() {
      return {
        selectActiv: '',
        activTotal: ['Python飞机大战01','Python飞机大战02','Python飞机大战03','Python飞机大战04',
          'Python基础语法','Python对象','Python函数','Python面向对象','Python切片'],
        ongoing:['Python飞机大战01','Python飞机大战02','Python飞机大战03','Python飞机大战04'],
        end: ['Python基础语法','Python对象','Python函数','Python面向对象','Python切片'],
        selected: 'first',
        stuTotal: 50,
        role: '',
//        studentList:[
//          {
//            stuNo: '180327001',
//            stuName: '张三',
//          },
//          {
//            stuNo: '180327002',
//            stuName: '李思',
//          }
//        ],
        studentList:[],
      }
    },
    mounted(){
      this.role = JSON.parse(localStorage.getItem('userInfo')).role
      console.log(this.role)
//      this.getRoleByUserId();
      this.getStudentList();
    },
    computed: {
    },
    methods: {
      // 获取用户角色
      getRoleByUserId(){
        var _this = this
        var params = {
          userName: JSON.parse(localStorage.getItem('userInfo')).userName
        }
        axios.get('/users/role',{
          params: params
          }).then(function (result) {
          var res = result.data;
          if(res.status =='0'){
            let user_info = res.result.list;
            _this.role = user_info[0].role;
            console.log(_this.role);
          }else {
            _this.role = null;
            console.log(_this.role);
          }
          this.getStudentList(_this.role);
        }.bind(_this)).catch((err) => {
          alert(err)
        })
      },
      getStudentList(){
        var params = {
        }
        if(this.role == 2){
          params = {
            userName: JSON.parse(localStorage.getItem('userInfo')).userName
          }
        }
        axios.get('/students',{
          params: params
        }).then((result)=>{
          var res = result.data;
          console.log(res);
          if(res.status =='0'){
            this.studentList = res.result.list;
//            console.log(this.studentList);
          }else {
            this.studentList = null;
//            console.log(this.studentList);
          }
        });
      },
      gotoSign(){
        console.log('去签到吧，皮卡丘')
        this.$router.push({
         name: 'sign',
          params: {courseName: this.courseName}
        })
      },

    },
    watch:{
      selected:function (oldval,newval) {
        console.log(oldval,newval);
//        this.$emit('selectedBar');
//        this.selected = this.selectedBar;
      },
      selectActiv(){
        console.log(this.activTotal.length)
      }
    }
  }
</script>
<style scoped>
  /*footer部分*/
  #footer{
    width: 100%;
    height: 40px;
    background:white;
    position: fixed;
    bottom: 0;
    margin: 0px;
  }
  .content{
    background-color: red;
    width: 100%;
    height: 100%;
    position: fixed;
  }
  .tabbar{
    background-color: #ffda44;
    width: 100%;
    height: 100%;
    position: fixed;
  }
  .page-source{
    /*background-color: #00B7FF;*/
    width: 100%;
    position: fixed;
    margin-top: 20px;
  }
  .mint-tab-container{
    /*background-color: #f6f6ae;*/
    width: 100%;
    height: auto;
    padding: 0px;
    /*margin: -663px; 565*/
    margin-top: -740px;
  }
  .activNavbar{
    /*background-color: red;*/
    height: 100%;
    width: 100%;
    position: fixed;
    margin: 8px 0px 0px 0px;
  }
  .activContainer{
    /*background-color: green;*/
    width: 100%;
    height: 100%;
    margin: 0px;
  }
   .mint-cell{
    /*background-color: green;*/
    width: 100%;
    /*height: 100%;*/
    position: relative;
     padding: 0px;
    text-align: left;
  }
  .student{
    /*background-color: #6641e2;*/
    margin-top: 180px;
  }
   .student label{
     width: 100%;
     text-align: left;
     margin-top: 20px;
   }
  .student svg{
    color: #ffda44;
    font-size: 400%;
    margin-top: 20px;
    text-align: center;
  }

</style>
