<template>
  <div class="nav-breadcrumb-wrap">
    <div class="container">
      <nav class="nav-breadcrumb">
        <a href="/">Home</a>
        <slot name="bread"></slot>
        <slot name="b"></slot>
      </nav>
    </div>
  </div>
</template>

