<template>
    <div class="hello">
      <link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
      <mt-header title="微签" style="background-color:#2bc4e2">
        <router-link to="" slot="left">
          <mt-button icon="back">创建班课</mt-button>
        </router-link>
      </mt-header>
      <div class="page-select">
        <mt-cell-swipe>
          <!--<a href="javascript:;" class="item-add-btn" @click="addCover">-->
          <svg class="icon icon-plus" @click="actionSheet"><use xlink:href="#icon-plus"></use></svg>
          <!--</a>-->
          <div class="bankelabel">
            <label class="mint-button-text">班课封面</label>
          </div>
        </mt-cell-swipe>
        <!--<div @click="showAll = !showAll" class="show-more">-->
        <div class="selectinfo">
          <!--<svg-icon slot="right" icon-class="example" style="font-size: 16px"></svg-icon>-->
          <!--{{word}}-->
          <p>设置学校、院系、所属学期等信息</p>
          <mt-cell class="show-more" title="设置班课详情" >
            <svg class="icon icon-cheveron-down"><use xlink:href="#icon-cheveron-down"></use></svg>
            <span @click="showAll = !showAll">{{word}}</span>
          </mt-cell>
          <mt-cell v-for='(item,index) in show' :key="index" is-link :to="item.path" @click.native="setVisible(index)" size="large">
            {{item.name}}
            <div class="page-picker-wrapper">
                <mt-popup v-model="popupVisible4" v-show="popupVisible4" position="bottom" class="mint-popup-4">
                  <span >设置学期<button @click="selectTerm()">完成</button></span>
                  <mt-picker :slots="termSlot" @change="onTermChange" :visible-item-count="5" :show-toolbar="false"></mt-picker>
                </mt-popup>


            </div>
          </mt-cell>
          <mt-button type="primary"size="large" @click.native="create">创建</mt-button>
        </div>
      </div>
      <footer>
        <mt-actionsheet
          :actions="actions"
          v-model="sheetVisible">
        </mt-actionsheet>
      </footer>

    </div>
</template>


<script>
  export default {
    data () {
      return {
        actions:[],
        sheetVisible:false,
        menuList: [
//          name: ['学校院系','所属学期','学习要求','教学进度','考试安排'],   //进行显示的数据
//          path:['/school','','/study','/teach','/exam'],
            {
              name: '学校院系',
              path:'/school',
            },
            {
              name: '所属学期',
              path: 'javascript:;',
              method: this.setVisible,
            },
            {
              name: '学习要求',
              path: '/study',
            },
            {
              name: '教学进度',
              path: '/teach',
            },
            {
              name: '考试安排',
              path: '/exam',
            },

        ],
        showAll:false,
        year: '1984',
        number: 0,
        termSlot: [{
          flex: 1,
          values: ['2014-2015学年上学期', '2014-2015学年下学期', '2015-2016学年上学期', '2015-2016学年下学期',
                    '2016-2017学年上学期', '2016-2017学年下学期', '2017-2018学年上学期', '2017-2018学年下学期',
                    '2018-2019学年上学期', '2018-2019学年下学期', '2019-2020学年上学期', '2019-2020学年下学期',
                    '2020-2021学年上学期', '2020-2021学年下学期', '2021-2022学年上学期', '2021-2022学年下学期',
                    '2022-2023学年上学期', '2022-2023学年下学期', '2023-2024学年上学期', '2023-2024学年下学期',],
          className: 'slot1'
        }],
        popupVisible4: false,
        buttonBottom: 0,
      }
    },
    mounted(){
      this.actions = [{
        name: '使用默认封面',
        method: this.getDefault
      },{
        name: '拍照',
        method: this.getCamera
      },{
        name: '从相册中选择',
        method: this.getAlbum
      }];
    },
    computed:{
      showList:function(){
      },
      word:function(){
        if(this.showAll == false){　　　　　　　　　　　//对文字进行处理
          return '点击展开'
        }else{
          return '点击收起'
        }
      },
      show(){
        if(this.showAll == true){
          if(this.menuList.length > 0){
              console.log(this.menuList);
              return this.menuList;
            }
          }
        },
//      onValuesChange(picker, values) {
//        if (values[0] > values[1]) {
//          picker.setSlotValue(1, values[0]);
//        }
//      },

    },
    methods: {
      actionSheet(){
        this.sheetVisible = true;
      },
      setVisible(item){
        console.log('选择:'+item);
////        console.log($event)
        if(item == 1){
          this.popupVisible4 = true;
        }
//        else {
//          $event[isTrusted] = false;
//        }
        console.log(this.popupVisible4);
      },
      onTermChange(picker, values) {
        if (values[0] > values[1]) {
          picker.setSlotValue(1, values[0]);
        }
        this.year = values[0];
      },
      selectTerm(){
        console.log('select学期')
      },
    }
  }
</script>
<style lang='scss' scoped>
  /*@import "style.scss";*/
  .hello{
    width: 100%;
    height: 100%;
    position: fixed;
  }
  .show-more{
    background-color: #55ffff;
    width: 100%;
  }
  .mint-cell{
    background-color: #e91e63;
    width: 100%;
    margin: 0px 10px 0px 0px;
  }

  /*@component-namespace page {*/
    /*@component popup {*/
      /*@descendent wrapper {*/
        /*padding: 0 20px;*/
        /*position: absolute 50% * * *;*/
        /*width: 100%;*/
        /*transform: translateY(-50%);*/
        /*button:not(:last-child) {*/
          /*margin-bottom: 20px;*/
        /*}*/
      /*}*/
      /*.mint-popup-1 {*/
        /*width: 200px;*/
        /*border-radius: 8px;*/
        /*padding: 10px;*/
        /*transform: translate(-50%, 0);*/
      /*h1 {*/
        /*font-size: 20px;*/
        /*color: #26a2ff;*/
      /*}*/
      /*p {*/
        /*margin-bottom: 10px;*/
      /*}*/
    /*}*/
    /*.mint-popup-1::before {*/
      /*triangle: 10px top #fff;*/
      /*content: '';*/
      /*position: absolute;*/
      /*top: -20px;*/
      /*right: 50px;*/
    /*}*/
    /*.mint-popup-2 {*/
      /*width: 100%;*/
      /*height: 50px;*/
      /*text-align: center;*/
      /*background-color: rgba(0,0,0,.7);*/
      /*backface-visibility: hidden;*/
    /*}*/
    /*.mint-popup-2 p {*/
      /*line-height: 50px;*/
      /*color: #fff;*/
    /*}*/
    /*.mint-popup-3 {*/
      /*width: 100%;*/
      /*height: 100%;*/
      /*background-color: #fff;*/
    /*}*/
    /*.mint-popup-3 .mint-button {*/
      /*position: absolute;*/
      /*width: 90%;*/
      /*top: 50%;*/
      /*left: 5%;*/
      /*transform: translateY(-50%);*/
    /*}*/
    /*.mint-popup-4 {*/
      /*width: 100%;*/
    /*.picker-slot-wrapper, .picker-item {*/
      /*backface-visibility: hidden;*/
    /*}*/
  /*}*/
  /*}*/
  /*}*/
  .page-picker-wrapper .mint-popup-4{
    background-color: #42b983;
    width: 100%;
    backface-visibility: hidden;
  }
  .page-picker-wrapper button{
    /*background-color: #42b983;*/
    margin: 0px 0px 0px 50px;
  }
  /*.mint-popup-4 {*/
    /*width: 100%;*/
    /*.picker-slot-wrapper, .picker-item {*/
      /*backface-visibility: hidden;*/
    /*}*/
  /*}*/
</style>
