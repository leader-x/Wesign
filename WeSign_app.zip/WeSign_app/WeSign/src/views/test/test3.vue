<template>
  <div id="depart">
    <link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
    <mt-header class="header" title="微签" style="background-color:#2bc4e2">
      <router-link to="/school" slot="left">
        <mt-button icon="back">院系</mt-button>
      </router-link>
      <mt-button slot="right" @click="select(searchValue)">完成</mt-button>
    </mt-header>
    <div class="page-depart">
      <div class="page-search">
        <mt-search autofocus
                   v-model="searchValue"
                   cancel-text="取消"
                   placeholder="输入院系名称搜索"
                   @keyup.enter.native="search"
                   :result.sync="filterResult">
        </mt-search>
      </div>
      <div id="depart-List">
        <mt-loadmore style="min-height: 100%;overflow: auto"
                     :top-method="loadTop"
                     :bottom-all-loaded="bottomAllLoaded"
                     :auto-fill="false"
                     @bottom-status-change="handleBottomChange"
                     @top-status-change="handleTopChange"
                     :bottom-method="loadBottom" ref="depart">

          <div slot="top" class="mint-loadmore-top">
          <span v-show="topStatus === 'loading'">
            数据加载中<i class="fa fa-spinner fa-pulse"></i>
          </span>
            <span v-show="topStatus === 'drop'">我在加载数据</span>
            <span v-show="topStatus === 'pull'">下拉我就更新</span>
          </div>
          <div slot="bottom" class="mint-loadmore-bottom" v-show="!bottomAllLoaded">
            <span v-show="bottomStatus === 'drop'">释放更新</span>
            <span v-show="bottomStatus === 'pull'">上拉加载更多</span>
            <span v-show="bottomStatus === 'loading'">
            数据加载中<i class="fa fa-spinner fa-pulse"></i>
          </span>
          </div>
          <!--<mt-cell>-->
          <!--<svg class="icon icon-checkbox-checked" slot="left" style="background-color: blue"><use xlink:href="#icon-checkbox-checked"></use></svg>-->
          <!--&lt;!&ndash;<img src="/static/images/qq.jpg"/>&ndash;&gt;-->
          <!--</mt-cell>-->

          <mt-cell-swipe
            v-for="(item,index) in filterResult" :key="index" v-model="value1"
            :title="item" :left="rightButtons" is-link @click.native="select(item,index)">
            <svg class="icon icon-checkbox-checked" v-show="show[index]">
              <use xlink:href="#icon-checkbox-checked"></use>
            </svg>
          </mt-cell-swipe>

          <!--<mt-radio-->
          <!--align="right"-->
           <!--v-model="value1"-->
          <!--:options="options">-->
          <!--</mt-radio>-->

          <!--<div>-->
          <!--<mt-cell title="选中的项">{{ value1 }}</mt-cell>-->
          <!--</div>-->

        </mt-loadmore>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">

  export default {
    data() {
      return {
        value1: '',
        searchValue: '',
        searchResult: [],
        show: [],
        showAll: false,
        bottomAllLoaded: false,
        topStatus: '',
        bottomStatus:'',
        options: [],
        departList: ['经管学院','外国语学院','法学院','土木工程学院','建筑学院',
          '化学学院','计算机学院','软件学院','人工智能学院'
        ],
      }
    },
    created() {
      this.rightButtons = [
        {
          content: 'Edit',
          style: { background: 'lightgray', color: '#fff' }
        },
        {
          content: 'Delete',
          style: { background: 'red', color: '#fff' },
          handler: () => this.$messagebox('delete')
        }
      ];

//      this.options = this.departList;
//      this.show = true;

      let _footer = this.$store.state.footerVisible;
      if (_footer) {
        this.$store.commit('TOGGLE_FOOTER');
      }
    },
    mounted(){
      this.init();
    },
    watch:{
    },
    computed:{
      //todo 从后台获取学院
      filterResult(){
//        this.searchResult.push({
//          title:this.departList.filter(value => new RegExp(this.searchValue, 'i').test(value)),
////          disabled:false
//        });
//        if(this.value1){
//          this.options= [];
//          console.log(this.departList.filter(value => new RegExp(this.value1, 'i').test(value)));
//          let value = this.departList.filter(value => new RegExp(this.value1, 'i').test(value));
//          for(let i=0; i< value.length; i++){
//            this.options.push({
//              value: value[i],
//              disabled: true
//            })
//          }
//        }
//        console.log(this.options)
//        return this.options;

        console.log(this.show)
        return this.departList.filter(value => new RegExp(this.searchValue, 'i').test(value));
      }
    },
    methods:{
      init(){
        for(let i=0;i<this.departList.length; i++){
          this.show[i] = false;
        }
        console.log(this.show);
        return this.show;
      },
      search(){
        return this.departList.filter(value => new RegExp(this.searchValue, 'i').test(value));
      },
      select(item,index){
        console.log('当前select：'+ item+ 'index:'+index);
//        console.log(this.show[index])
        this.show[index] = !this.show[index]
        console.log(this.show);
        console.log(this.$route.query);
        this.$router.push({
          path:'/createClass',
          query:{
            school:this.$route.query.school,
            depart:item
          }
        });
      },
      leftButtonHandler(evt) {
        console.log(123);
      },

      delete1(val){
        console.info('delete:' + val)
      },
      loadTop(){
        let that = this;
        setTimeout(function () {
          that.$refs.depart.onTopLoaded();
        }, 1000);

      },
      loadBottom(){
        if (this.departList.length > 100) {
          this.bottomAllLoaded = true;
        }
        this.$refs.depart.onBottomLoaded();
      },
      handleTopChange(status){
        this.topStatus = status;
      },
      handleBottomChange(status) {
        this.bottomStatus = status;
      },

    }
  }
</script>
<style scoped>
  #depart{
    /*background-color: #e91e63;*/
    width: 100%;
    position: fixed;
    margin: 0px 10px 0px 0px;
  }
  .header{
    /*background-color: #e91e63;*/
    width: 100%;
  }
  .page-depart{
    /*background-color: #42b983;*/
    height: 100%;
  }
  .mint-search{
    /*background-color: #f6f6ae;*/
    width: 100%;
    height: 45px;
    position: relative;
  }
  #depart-List{
    background-color: #2bc4e2;
    height: 100%;
    text-align: left;
    margin: 0px 0px 0px 0px;
  }
  .mint-cell-swipe{
    background-color: #42b983;
    width: 100%;
    /*text-align: left;*/
  }
  .mint-cell{
    /*background-color: #f6f6ae;*/
    /*margin: 0px 0px 0px 0px;*/
  }
  .icon {
    display: inline-block;
    width: 1em;
    height: 1em;
    stroke-width: 0;
    stroke: currentColor;
    fill: #ffda44;
  }


</style>
