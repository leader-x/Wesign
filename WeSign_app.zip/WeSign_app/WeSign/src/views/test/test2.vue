<template>
  <div class="page-indexlist">
    <!--<h1 class="page-title">Index List</h1>-->
    <!--<p class="page-indexlist-desc">此例请使用手机查看</p>-->
    <!--<form action="" target="frameFile">-->
      <!--<mt-search-->
        <!--autofocus-->
        <!--v-model="value"-->
        <!--:result="filterResult"-->
        <!--cancel-text="取消"-->
        <!--placeholder="搜索"-->
        <!--@keyup.enter.native="search">-->
      <!--</mt-search>-->
    <!--</form>-->

    <div class="page-indexlist-wrapper">
      <div class="div_sech">
        <form action="" target="frameFile">
          <mt-search  autofocus
                      v-model="value" cancel-text="取消"  placeholder="搜索"

                      @keyup.enter.native="search">
          </mt-search>
          <mt-index-list>
            <mt-index-section v-for="(item,index) in searchResult" :key="index" :index="item.initial">
              <mt-cell v-for="(cell,index) in item.cells" :key="index" :title="cell" v-on:click="select">
                <svg class="icon icon-checkbox-checked" v-show="selected">
                  <use xlink:href="#icon-checkbox-checked"></use>
                </svg>
              </mt-cell>


                <!--<svg-icon icon-class="checkbox-checked"></svg-icon>-->
                <!--<svg-icon icon-class="user" style="font-size: 18px"></svg-icon>-->

              <!--<img src="/static/images/qq.jpg"/>-->

            </mt-index-section>
          </mt-index-list>
        </form>
        <iframe name='frameFile' style="display: none;"></iframe>
      </div>
    </div>

  </div>
</template>

<script type="text/babel">

  import {ConvertPinyin} from '@/utils/hanzi2pinyin'

  const NAMES = ['艾伦', '艾尔登', '奥斯汀', '柏德文', '布兰登', '卡拉', '钱德尔', '克里德', '大卫', '一哥', '艾顿', '弗洛伊德',
    '福瑞曼', '盖文', '恒科拓', '亨利', '怡安', '杰森', '月华', 'Kane', '兰伯特', 'Matthew', '摩根', 'Neville', '奥利弗',
    '奥斯卡', '皮锐', 'Quinn', 'Ramsey', 'Scott', '赛斯', 'Spencer', 'Timothy', 'Todd', 'Trevor',
    'Udolf', '维克多', 'Vincent', '沃顿', 'Willis', 'Xavier', 'Yvonne', 'Zack', 'Zane'];

  export default {
    data() {
      return {
        value: '',
        selected: false,
        alphabet: [],
        searchResult: [],
        nameList:['Apple',
          'Banana',
          'Orange',
          'Durian',
          'Lemon',
          'Peach',
          'Cherry',
          'Berry',
          'Core',
          'Fig',
          'Haw',
          'Melon',
          'Plum',
          'Pear',
          'Peanut',
          'Other'],
      };
    },
    mounted(){
      console.log(this.alphabet);
      this.searchResult = this.alphabet;
    },
    computed: {
      filterResult() {
        console.log(this.value);
//        if(this.value == ''){
////          this.searchResult = this.alphabet;
//        }else {
          this.searchResult = [];
          this.alphabet.forEach(item => {
            let cells = item.cells.filter(value => new RegExp(this.value, 'i').test(value));
            let initial = item.initial;
            if(cells.length > 0){
              this.searchResult.push({
                initial,
                cells
              });
            }
          });
          /*
          //或
          for(let i=0;i<this.alphabet.length;i++){
            let cells = this.alphabet[i].cells.filter(value => new RegExp(this.value, 'i').test(value));
            let initial = this.alphabet[i].initial;
            if(cells.length> 0){
              this.searchResult.push({
              initial,
              cells
            });
            }
          } */
//        }
        console.log(this.searchResult);
//        return this.alphabet.filter(value => new RegExp(this.value, 'i').test(value));
        return this.searchResult;
      },
    },
    created() {
      //汉字转拼音
      'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').forEach(initial => {
        let cells = NAMES.filter(name => ConvertPinyin(name)[0].toUpperCase() === initial
        );
        this.alphabet.push({
          initial,
          cells
        });
      });
//      console.log(this.alphabet)
    },
    methods:{
      search(){
        console.log('search');
//        console.log(this.filterResult);
        return this.filterResult;
//        return this.nameList.filter(value => new RegExp(this.value, 'i').test(value));
      },
      select(){
        console.log('select')
      },

    }
  };
</script>

<style>
  /*@component-namespace page {*/
    /*@component indexlist {*/
    /*{*/
      /*background-color: #42b983;*/
    /*}*/
      /*@descendent desc {*/
        /*text-align: center;*/
        /*color: #42b983;*/
        /*padding-bottom: 5px;*/
      /*}*/
      /*@descendent wrapper {*/
        /*width: 100%;*/
        /*border-top: solid 1px #e91e63;*/
      /*}*/
    /*}*/
  /*}*/
  .page-indexlist{
    /*background-color: #e91e63;*/
    width: 100%;
    position: fixed;
    margin: 0px 0px 0px -10px;
  }
  .page-indexlist-wrapper .mint-search{
    /*background-color: #ffda44;*/
    width: 100%;
    height: 100%;
    position: relative;
    margin: 0px 10px 0px 0px;
  }
  /*.mint-search{*/
    /*background-color: #e91e63;*/
    /*width: 100px;*/
    /*height: 100%;*/
    /*text-align: left;*/
    /*position: relative;*/
  /*}*/
  .mint-cell{
    background-color: #42b983;
    text-align: left;
    margin: 0px 0px 0px 0px;
  }
  .icon {
    display: inline-block;
    width: 1em;
    height: 1em;
    stroke-width: 0;
    stroke: currentColor;
    fill: #ffda44;
  }

</style>
