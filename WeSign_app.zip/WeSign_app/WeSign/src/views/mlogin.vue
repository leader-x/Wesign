<template>
  <div class="index">
    <div id="index_pc_bj">
      <form ref="formLogin" :model="formLogin" :rules="ruleLogin">
        <div class="wrap_conter">
          <ul style="list-style: none; box-shadow:1px 1px 20px rgba(0,0,0,.5);">
            <li style="border-bottom: 1px solid #e91e63;">
              <div class="content">
                <img src="../../static/images/logo.jpg" style="width: 40px;height: 40px;" align="absmiddle" />
                <span style="float:right;font-size: 15px">欢迎登陆</span>
              </div>
            </li>
            <li>
              <div class="name-password-error" v-if="this.$store.state.ifSign">用户名或密码错误</div>
              <dl>
                <div>
                  <svg-icon icon-class="user" slot="prepend" style="background-color: #aaaaaa;font-size: 16px"/>
                  <input class="mini-textbox" v-model="formLogin.userName" type="text" placeholder="登录名" :rule="ruleLogin.userName" />
                </div>
                <div>
                  <svg-icon icon-class="password" slot="prepend" style="background-color: #aaaaaa;font-size: 16px"/>
                  <input class="mini-textbox" v-model="formLogin.password" type="password" placeholder="密码" />
                </div>
                <div>
                  <mt-button type="primary" @click="login('formLogin')" style="width: 180px;margin-left: 0px">登录</mt-button>
                </div>
                <ul class="account-list">
                  <li>
                    <a href="https://github.com/login/oauth/authorize?client_id=bbb5cc2034eb62484c1c&state=github" style="{right: 26px;}">
                      <img class="icon" src="../../static/images/GitHub.svg" /></a>
                  </li>
                  <li>
                    <a href="https://graph.qq.com/oauth2.0/authorize?response_type=code&client_id=101512648&redirect_uri=http://www.lovemtt.com/qq&state=qq" style="{right: 26px;}">
                      <img class="icon" src="../../static/images/social-qq.svg" /></a>
                  </li>
                </ul>
              </dl>
            </li>
          </ul>
        </div>
     </form>
    </div>
  </div>
</template>
<script>
  import axios from 'axios'
export default {
  data() {
    return {
      code: null,
      formLogin: {
        userName: null,
        password: null
      },
      ruleLogin: {
        userName: [
          { required: true, message: "请填写用户名", trigger: "blur" }
        ],
        password: [{ required: true, message: "请填写密码", trigger: "blur" }]
      }
    };
  },
  mounted() {
    if (!this.$store.getters._isMobile) {
      this.$router.replace("/login");
    }
  },
  methods: {
    login(formLogin) {
      console.log(this.$refs[formLogin]);
//      this.$refs[formLogin].validate(valid => {
//        if (valid) {
//          this.$store.dispatch("users/userLogin", {
//            user_name: this.formLogin.userName,
//            user_password: this.formLogin.password,
//            router: this.$router
//          });
//        }
//      });
      if(this.formLogin.userName=='' || this.formLogin.password=='' ){
        this.$toast({
          message: '用户名或密码不能为空',
          position: 'bottom',
          iconClass: 'icon icon-err',
          duration: 3000
        });
      }else {
        //todo 请求后端数据
//        this.$router.push({path: "/Home"});
        axios.post("/users/login",{
          userName:this.formLogin.userName,
          userPwd:this.formLogin.password
        }).then((response)=>{
          let res = response.data;
          if(res.status == "0"){ // 登录成功
            this.$router.push({path: "/Home"});
          }else {
//            this.errorTip = true;
          }
        }).catch((error) => {
          console.log(error)
        });
      }
    },
    register() {
      this.$router.push({ path: "/register" });
    }
  }
};
</script>
<st src="../../scripts/boot.js" type="text/javascript"></st>

<style scoped>
  .index {
    width: 100%;
    align-items: center;
    display: flex;
    position: fixed;
    top: 0;
    bottom: 0;
    left: 0;
    text-align: center;
    background-image: url(../../static/images/login.jpg);
  }
  .index .ivu-row-flex {
    height: 100%;
  }
  #index_pc_bj {
    width: 100%;
    height: auto;
    background-size: cover;
    overflow: hidden;
    background-position: center center; /*box-shadow: 0 0px 3px rgba(0,0,0,.5);*/
    text-align: center;
  }
  /*具体内容*/
  .wrap_conter ul {
    position: relative;
    width: 300px; /*border:5px solid rgba(255,255,255,0.3);*/
    height: 250px;
    border-radius: 5px;
    background: #fff;
    text-align: center;
    margin: 0 auto;
  }
  .wrap_conter li {
    text-align: center;
    color: #fff;
    font-size: 12px;
    line-height: 30px;
    padding: 0 10px 0px -5px;
    margin:  0 20px 0px -40px;
    width: 100%;
  }
  .content {
    color: #1c2438;
    line-height: 40px;
    display: block;
    text-align: left;
    padding: 5px 0 0 0;
    margin: 0 30px 0 30px;
  }
  .pc-hign {
    height: 75px;
    display: inline-table;
  }
  /*.wrap_conter li dl {*/
    /*width: 100%;*/
    /*!*margin-top: 10px;*!*/
    /*margin:10px 50px 0px 0px;*/
  /*}*/
  .name-password-error {
    padding-bottom: 2px;
    text-align: left;
    line-height: 1;
    color: #ed3f14;
  }
  /*.ivu-form-item-content {*/
    /*width: auto;*/
    /*padding-top: 10px;*/
  /*}*/
  .account-list ul{
    width: auto;
    padding-top: 10px;
    margin:10px 50px 0px 0px;
  }
  .account-list li {
    width: auto;
    display: inline-block;
    margin: 0px 60px 0px -20px;
  }

  .account-list .icon {
    width: 35px;
    height: 40px;
  }
</style>
