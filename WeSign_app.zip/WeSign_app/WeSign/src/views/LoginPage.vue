<template>
  <div id="app">
    <header>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      <title>WeSign登录页面</title>
      <link href="./../css/style.css" rel="stylesheet" type="text/css" />
    </header>
    <body>
    <div class="top">
      <ul>
        <li><a href="#none" class="hover">系统主页</a></li>
        <li><a href="#none">账号注册</a></li>
        <li><a href="#none">首页</a></li>
        <li><a href="#none">联系我们</a></li>
      </ul>
    </div>
    <div class="main">
      <div class="denglu">
        <div class="dlk">
          <table width="292" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td height="76" colspan="3"></td>
            </tr>
            <tr>
              <td width="65" style="font-size:14px;">用户名</td>
              <td colspan="2">
                <input id="userName" type="text" class="dlinput"  v-model="userName"/>
              </td>
            </tr>
            <tr>
              <td height="16" colspan="3"></td>
            </tr>
            <tr>
              <td>登录密码</td>
              <td colspan="2">
                <input id="password" type="password" class="dlinput" v-model="password"/>
              </td>
            </tr>
            <tr>
              <td height="16" colspan="3"></td>
            </tr>
            <tr>
              <td>验证码</td>
              <td width="100">
                <input id="code" type="text" class="dlinput" style="width:90px;" maxlength="4" v-model="code"/>
              </td>
              <td width="127"><img src="../../static/images/code.png" width="98" height="27" /></td>
            </tr>
            <tr>
              <td height="16" colspan="3"></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td colspan="2">
                <input type="button" value="登 录" class="loginbtn" @click="submit"/>
              </td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td colspan="2"><table width="224" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td height="24"><a href="#none" class="mm">忘记密码？</a></td>
                  <td align="right"><a href="#none" class="zc" style="font-size:13px;">立即注册</a></td>
                </tr>
              </table></td>
            </tr>
          </table>
        </div>
      </div>
      <!--<div class="footer"><span>Copyright &copy; 2019　WeSign设计团队</span></div>-->
    </div>

    </body>
  </div>
</template>

<script type="text/ecmascript-6">

  import axios from 'axios'

  export default {
    name: 'loginPage',
    data(){
      return {
        msg: '欢迎',
        userName: '',
        password: '',
        code: '',
        userList: [],
      }
    },
    components:{

    },
    mounted(){
      this.getUserInfo();
    },
    methods:{
      getUserInfo(){
//        this.axios.get("/data/userInfo.json").then((result)=>{
//          var res = result.data;
//          this.userList = res.result;
//        })
      },
      submit(){
        // 判断登录，从后台数据库，暂时先用假数据
        if(this.userName == null || this.password == null){
          alert("用户名或密码不能为空");
        }else if(this.userName == this.goodsList.userName && this.password == this.goodsList.password){
          if(this.code == null){
            alert("验证码不能为空");
          }else if(this.code == this.userList.code){
            //todo 注册成功待跳转
            console.log('注册成功');
          }else {
            alert('验证码不正确，请重新输入！');
          }
        }
      }
    },
  }
</script>

<style scoped>
  /* CSS Document */
  body {
    font-family:Helvetica, sans-serif;
    font-size: 14px;
    padding: 0;
    margin: 0;
    color: #333;
  }
  a:link {
    color: #666;
    text-decoration: none;
  }
  a:visited {
    color: #666;
    text-decoration: none;
  }
  a:hover {
    color: #C00;
    text-decoration: none;
  }
  ul,ol,li {
    margin: 0;
    padding: 0;
    list-style-type: none;
  }
  dl,dt,dd {
    margin: 0;
    padding: 0;
  }
  img {
    border: 0;
  }
  br {
    font-size: 0;
    line-height: 10px;
    height: 10px;
  }

  /* 头部 */
  .top {
    width: 980px;
    height: 90px;
    margin: 0 auto;
    /*background: url(../../static/images/background.jpg) no-repeat left center;*/
  }
  .top ul {
    height: 90px;
    line-height: 90px;
    float: right;
  }
  .top ul li {
    float: left;
    margin-left: 30px;
    font-weight: bold;
  }
  .top ul li a.hover {
    color: #F60;
  }
  .top ul li a.hover:hover {
    color: #C00;
  }

  /* 登录主体 */
  .main {
    height: 520px;
    background: url(../../static/images/tp02_20140320.png) repeat-x;
  }
  .main .denglu {
    width: 1280px;
    height: 520px;
    background: url(../../static/images/background.jpg) no-repeat;
    margin: 0 auto;
    position: relative;
  }
  .main .denglu .text {
    width: 450px;
    position: absolute;
    left: 260px;
    top: 155px;
    line-height: 26px;
  }
  .main .denglu .dlk {
    width: 354px;
    height: 328px;
    background: url(../../static/images/tp03_20140320.png) no-repeat;
    position: absolute;
    right: 180px;
    top: 120px;
    color: #999;
  }
  .main .denglu .dlk a.mm {
    color: #000;
    font-size: 14px;
  }
  .main .denglu .dlk a.mm:hover {
    color: #C00;
  }
  .main .denglu .dlk a.zc {
    color: #F60;
  }
  .main .denglu .dlk a.zc:hover {
    color: #C00;
  }

  /* 登录底部 */
  .footer {
    font-size: 13px;
    height: 70px;
    line-height:70px;
    background: url(../../static/images/tp07_20140320.png) repeat-x;
    text-align: center;
    color: #666;
  }

  /* button,input */
  .dlinput {
    margin: 0;
    padding: 0;
    border: 1px solid #ccc;
    width: 222px;
    height: 34px;
    line-height: 34px;
    text-indent: 2px;
    font-size: 14px;

  }
  .loginbtn {
    -moz-border-bottom-colors: none;
    -moz-border-left-colors: none;
    -moz-border-right-colors: none;
    -moz-border-top-colors: none;
    background: url(../../static/images/tp06_20140320.png) no-repeat;
    border: none 0;
    width: 224px;
    height: 40px;
    line-height: 40px;
    cursor: pointer;
    font-family: "微软雅黑";
    font-size: 16px;
    color: #FFF;
    padding: 0;
    margin: 0;
  }
  .loginbtn:hover, .loginbtn:focus {
    background: url(../../static/images/tp07_20140320.png) no-repeat;
  }
  .loginbtn:active {
    color: #ccc;
  }
</style>
