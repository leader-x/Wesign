<template>
  <div id="teach">
    <link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
    <mt-header class="header" title="微签" style="background-color:#2bc4e2">
      <router-link to="/createClass" slot="left">
        <mt-button icon="back">教学进度</mt-button>
      </router-link>
      <mt-button slot="right" @click="finish(value)">完成</mt-button>
    </mt-header>
    <div id="content">
      <p>还可以输入{{count-value.length}}个字</p>
      <mt-field  :placeholder="`请填写教学进度，最多${count}个字`"
                 type="textarea" rows="4" v-model="value" :attr="{maxlength:`${count}`}"></mt-field>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">

  export default {
    data() {
      return {
        value: '',
        count: 20
      }
    },
    methods:{
      finish(item){
        //请同学们认真复习，上课内容至少复习一遍！
        console.log('finish:'+item);
        this.$router.push({
          path: '/createClass',
          query:{
            teach: item
          }
        });
      }
    }
  }
</script>
<style scoped>
  #teach{
    /*background-color: #e91e63;*/
    width: 100%;
    position: fixed;
  }
  .header{
    /*background-color: #e91e63;*/
    width: 100%;
  }
   .mint-field.is-textarea{
    /*background-color: #42b983;*/
  }
</style>
