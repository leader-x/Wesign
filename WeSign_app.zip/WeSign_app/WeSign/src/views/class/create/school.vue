<template>
  <div id="school">
    <link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
    <mt-header class="header" title="微签" style="background-color:#2bc4e2">
      <router-link to="/createClass" slot="left">
        <mt-button icon="back">选择学校</mt-button>
      </router-link>
    </mt-header>
    <div class="page-indexlist-wrapper">
      <div class="div-sech">
        <form action="" target="frameFile">
          <mt-search autofocus
                     v-model="value"
                     cancel-text="取消"
                     placeholder="输入学校名搜索"
                     @keyup.enter.native="search">
            <!--:result.sync="filterResult">-->
          </mt-search>
          <mt-index-list>
            <mt-index-section v-for="(item,index) in searchResult" :key="index" :index="item.initial">
              <mt-cell v-for="(cell,index) in item.cells" :key="index" :title="cell" is-link :to="{path:'/depart',query:{school:cell}}"></mt-cell>
            </mt-index-section>
          </mt-index-list>
        </form>
        <iframe name='frameFile' style="display: none;"></iframe>
      </div>
    </div>
      <!--<div id="school-List">-->
        <!--<mt-cell v-for="(item,index) in show" :key="index" :title="item" is-link to="/depart"></mt-cell>-->
      <!--</div>-->

    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import {ConvertPinyin} from '@/utils/hanzi2pinyin'

  export default {
    data() {
      return {
        value: '',
        searchResult: [],
        schoolList:['北京大学','清华大学','复旦大学','上海交大','南京大学',
          '浙江大学','中科大','武汉大学','华中科技大学','厦门大学','北京师范大学',
          '南开大学','中山大学','华南理工大学','湖南大学','中南大学','四川大学','福州大学',
          '家里蹲大学','天上飞大学','地上跑大学','安德鲁森大学','城市大学','欧克莱大学',
        ],
        alphabet: [],
      }
    },
    created(){
      'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').forEach(initial => {
        let cells = this.schoolList.filter(name => ConvertPinyin(name)[0].toUpperCase() === initial
        );
        this.alphabet.push({
          initial,
          cells
        });
      });
    },
    mounted(){
      this.initSchool();
    },
    computed: {
      filterResult() {
          this.searchResult = [];
          this.alphabet.forEach(item => {
            let cells = item.cells.filter(value => new RegExp(this.value, 'i').test(value));
            let initial = item.initial;
            if(cells.length > 0){
              this.searchResult.push({
                initial,
                cells
              });
            }
          });
        console.log(this.searchResult);
//        return this.schoolList.filter(value => new RegExp(this.searchValue, 'i').test(value));
        return this.searchResult;
      },
//      show(){
//        var show = [];
//        show = this.schoolList;
//        console.log(show)
//        return show;
//      },

    },
    methods:{
      initSchool(){
        this.searchResult = this.alphabet;
      },
      search(){
        console.log('search');
        return this.filterResult;
//        return this.schoolList.filter(value => new RegExp(this.searchValue, 'i').test(value));
      },
    }
  }
</script>
<style scoped>
  #school{
    /*background-color: #e91e63;*/
    width: 100%;
    position: fixed;
    margin: 0px 0px 0px 0px;
  }
  .header{
    /*background-color: #e91e63;*/
    width: 100%;
  }

  /*.mint-search{*/
    /*background-color: #55ffff;*/
    /*width: 100%;*/
    /*height: 100%;*/
    /*position: fixed;*/
  /*}*/
  /*.page-indexlist-wrapper .mint-cell{*/
    /*background-color: #42b983;*/
    /*text-align: left;*/
    /*width: 350px;*/
  /*}*/

  .page-indexlist-wrapper .mint-search{
    /*background-color: #e91e63;*/
    width: 100%;
    height: 100%;
    position: relative;
    margin: 0px 10px 0px 0px;
  }
  /*.mint-search{*/
  /*background-color: #e91e63;*/
  /*width: 100px;*/
  /*height: 100%;*/
  /*text-align: left;*/
  /*position: relative;*/
  /*}*/
  .mint-cell{
    background-color: #42b983;
    text-align: left;
    margin: 0px 0px 0px 0px;
  }

</style>
