<template>
  <div id="banke">
    <link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
    <mt-header title="微签">
      <router-link to="/home" slot="left">
        <mt-button icon="back">创建班课</mt-button>
      </router-link>
    </mt-header>
    <div class="page-cell">
      <mt-cell-swipe>
        <!--<a href="javascript:;" class="item-add-btn" @click="addCover">-->
          <svg class="icon icon-plus" @click="actionSheet"><use xlink:href="#icon-plus"></use></svg>
        <!--</a>-->
        <div class="bankelabel">
          <label class="mint-button-text">班课封面</label>
        </div>
      </mt-cell-swipe>
      <mt-field label="班级" placeholder="未设置" v-model="className"></mt-field>
      <mt-field label="课程名" placeholder="未设置" v-model="courseName"></mt-field>
      <div class="page-radio">
        <p>类型</p>
        <mt-cell title="学校班课">
          <!--<label><input name="Fruit" type="radio"value="" style="margin: 10px 60px 0px 0px" /></label>-->
        </mt-cell>
      </div>
      <div class="page-select">
        <p>设置学校、院系、所属学期等信息</p>
        <mt-cell class="show-more" title="设置班课详情" >
          <svg class="icon icon-cheveron-down"><use xlink:href="#icon-cheveron-down"></use></svg>
          <span @click="showAll = !showAll">{{word}}</span>
        </mt-cell>
        <!--<div @click="showAll = !showAll" class="show-more">-->
          <!---->
        <!--</div>-->
        <div class="detail">
          <mt-cell
                   v-for='(item,index) in show' :key="index"
                   :title="item.name" :label="item.label" is-link :to="item.path" :value="item.value" @click.native="setVisible(index)">
          </mt-cell>
          <mt-button type="primary"size="large" @click.native="create">创建</mt-button>
        </div>
      </div>
      <footer>
        <mt-actionsheet
          :actions="actions"
          v-model="sheetVisible">
        </mt-actionsheet>
        <div class="page-picker-wrapper">
          <mt-popup v-model="popupVisible" position="bottom" class="mint-popup-4">
            <mt-picker :slots="termSlot" @change="onTermChange" :visible-item-count="5" :show-toolbar="false"></mt-picker>
          </mt-popup>
        </div>
      </footer>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import { Toast } from 'mint-ui';
  export default {
    data() {
      return {
        className: '',
        courseName: '',
        checked: false,
        actions:[],
        sheetVisible:false,
        menuList: [
          {
            name: '学校院系',
            path: '/school',
            label: '',
            value: '',
          },
          {
            name: '所属学期',
            path: 'javascript:;',
            label:'',
            value: '',
          },
          {
            name: '学习要求',
            path: '/study',
            label:'',
            value: '',
          },
          {
            name: '教学进度',
            path: '/teach',
            label:'',
            value: '',
          },
          {
            name: '考试安排',
            path: '/exam',
            label:'',
            value: '',
          }
        ],
        showAll: false,  　　　　　　　　　　　　　　　　//标记数据是否需要显示的属性
        term: '2014-2015学年上学期',
        termSlot: [{
          flex: 1,
          values: ['2014-2015学年上学期', '2014-2015学年下学期', '2015-2016学年上学期', '2015-2016学年下学期',
            '2016-2017学年上学期', '2016-2017学年下学期', '2017-2018学年上学期', '2017-2018学年下学期',
            '2018-2019学年上学期', '2018-2019学年下学期', '2019-2020学年上学期', '2019-2020学年下学期',
            '2020-2021学年上学期', '2020-2021学年下学期', '2021-2022学年上学期', '2021-2022学年下学期',
            '2022-2023学年上学期', '2022-2023学年下学期', '2023-2024学年上学期', '2023-2024学年下学期',],
          className: 'slot1'
        }],
        popupVisible: false,
        buttonBottom: 0,
      }
    },
    mounted(){
      this.actions = [{
        name: '使用默认封面',
        method: this.getDefault
      },{
        name: '拍照',
        method: this.getCamera
      },{
        name: '从相册中选择',
        method: this.getAlbum
      }];
    },
    computed: {
      show() {
        if (this.showAll == true) {
          if (this.menuList.length > 0) {
           this.menuList.forEach(item => {
             if(item.name.indexOf('学校院系')>-1){
               item.label = this.$route.query.school+ ' '+ this.$route.query.depart;
             }
             if(item.name.indexOf('学习要求')>-1){
               item.value = this.$route.query.study;
             }
             if(item.name.indexOf('教学进度')>-1){
               item.value = this.$route.query.teach;
             }
             if(item.name.indexOf('考试安排')>-1){
               item.value = this.$route.query.exam;
             }
           })
//            console.log(this.menuList);
            return this.menuList;
          }
        }
      },
      word: function () {
        if (this.showAll == false) {　　　　　　　　　　　//对文字进行处理
          return '点击展开'
        } else {
          return '点击收起'
        }
      },
    },
    methods: {
      leftButtonHandler(evt) {
        console.log(123);
      },
      //添加封面action
      actionSheet(){
        this.sheetVisible = true;
      },
      //使用默认封面
      getDefault(){
        console.log('使用默认封面');
      },
      //todo 调用拍照接口
      getCamera(){
        console.log('打开摄像机');
      },
      // todo 打开相册
      getAlbum(){
        console.log('打开相册');
      },
      addCover(){
        console.log('添加封面');
      },
      setVisible(item){
        console.log('选择:'+item);
        if(item == 1){
          this.popupVisible = true;
        }
      },
      onTermChange(picker, values) {
        console.log('选择学期')
        if (values[0] > values[1]) {
          picker.setSlotValue(1, values[0]);
        }
        this.term = values[0];
      },
      create(){
        if(this.className== ''){
          this.showToast('请输入班级名称');
        }else if(this.courseName== '') {
          this.showToast('请输入课程名称');
        }else {
          //todo 调用创建班课后台接口
          console.log('班课创建成功');
          this.$router.push('/createSuccess')
        }

      },
      showToast(msg){
        let instance = this.$toast({
          message: msg ,
          position: 'middle',
          iconClass: 'icon icon-err',
          duration: 2000
        });
      },
    }
  }
</script>
<style scoped>
  #banke .mint-header{
    width: 100%;
    margin: 0px 300px 0px 0px;
    padding: 0px;
    position: relative;
    /*background-color: #dc3958;*/
  }
  .icon {
    display: inline-block;
    width: 2em;
    height: 2em;
    stroke-width: 0;
    margin: 10px 100px 10px -50px;
    /*padding: 2px;*/
    stroke: currentColor;
    fill: currentColor;
  }
  .icon icon-cheveron-down{
    display: inline-block;
    width: 2em;
    height: 2em;
    stroke-width: 0;
    margin: 0px 100px 10px -50px;
    stroke: currentColor;
    fill: currentColor;;
  }
  .mint-cell-swipe{
    /*background-color: #e91e63;*/
    height: 100%;
    padding: 0px;
  }
  .mint-cell{
    /*background-color: #e91e63;*/
    text-align: left;
    width: 100%;
  }
  .mint-cell .mint-cell-wrapper{
    background-color: #e91e63;
    text-align: left;
    width: 100%;
  }
  .detail{
    /*background-color: blue;*/
    width: 100%;
    /*text-align: left;*/
    position: relative;
    /*fill: 100%;*/
  }

  .detail .mint-cell {
    /*background-color: #42b983;*/
    width:92%;
    height: 100%;
    position: relative;
    /*text-align: left;*/
  }

  .page-radio p{
    /*background-color: #e91e63;*/
    /*width: 500px;*/
    text-align: left;
    margin: 10px 0px 0px 10px;
    position: relative;
  }
  .page-radio {
    margin-top: 10px;
    margin-right: 20px;
  }
  .page-select {
    /*background-color: #e91e63;*/
    /*width: 500px;*/
    /*text-align: left;*/
    margin: 10px 10px 0px 0px;
    position: relative;
  }
  .page-select p{
    text-align: left;
  }
  /*.page-select .show-more {*/
    /*background-color: #42b983;*/
    /*margin: 0px 0px 0px 0px;*/
    /*position: relative;*/
  /*}*/
  .page-select .show-more span{
    margin: 0px 50px 0px -30px;
    position: relative;
  }

  .bankelabel{
    /*background-color: blue;*/
    position: relative;
    /*text-align: left;*/
    margin: 50px 100px 0px -50px;
  }

  .page-picker-wrapper .mint-popup-4{
    background-color: #ffda44;
    width: 100%;
    backface-visibility: hidden;
  }

</style>
