<template>
  <div id="bankeQRCode">
    <div class="navheader">
      <link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
      <mt-header title="微签">
        <router-link to="/createClass" slot="left">
          <mt-button icon="back">创建成功</mt-button>
        </router-link>
      </mt-header>
    </div>
    <div class="content">
        <span>恭喜你成功创建班课<br/>
      快将班课号/二维码告诉你的学生吧<br/>
      </span>
        <svg class="icon icon-gnu" font-size="150px"><use xlink:href="#icon-gnu"></use></svg><br/>
        <!--或者&lt;!&ndash;<svg-icon icon-class="gnu" font-size="100px"></svg-icon><br/>&ndash;&gt;-->
        <!--<img src="/static/images/brand.jpg"/>-->
        <span style="color: red">班课号{{bankeNum}}</span><br/>
        <svg class="icon icon-qrcode" font-size="150px">
          <symbol id="icon-qrcode" viewBox="0 0 32 32">
            <title>qrcode</title>
            <path d="M10 2h-8v8h8v-8zM12 0v0 12h-12v-12h12zM4 4h4v4h-4zM30 2h-8v8h8v-8zM32 0v0 12h-12v-12h12zM24 4h4v4h-4zM10 22h-8v8h8v-8zM12 20v0 12h-12v-12h12zM4 24h4v4h-4zM14 0h2v2h-2zM16 2h2v2h-2zM14 4h2v2h-2zM16 6h2v2h-2zM14 8h2v2h-2zM16 10h2v2h-2zM14 12h2v2h-2zM14 16h2v2h-2zM16 18h2v2h-2zM14 20h2v2h-2zM16 22h2v2h-2zM14 24h2v2h-2zM16 26h2v2h-2zM14 28h2v2h-2zM16 30h2v2h-2zM30 16h2v2h-2zM2 16h2v2h-2zM4 14h2v2h-2zM0 14h2v2h-2zM8 14h2v2h-2zM10 16h2v2h-2zM12 14h2v2h-2zM18 16h2v2h-2zM20 14h2v2h-2zM22 16h2v2h-2zM24 14h2v2h-2zM26 16h2v2h-2zM28 14h2v2h-2zM30 20h2v2h-2zM18 20h2v2h-2zM20 18h2v2h-2zM22 20h2v2h-2zM26 20h2v2h-2zM28 18h2v2h-2zM30 24h2v2h-2zM18 24h2v2h-2zM20 22h2v2h-2zM24 22h2v2h-2zM26 24h2v2h-2zM28 22h2v2h-2zM30 28h2v2h-2zM20 26h2v2h-2zM22 28h2v2h-2zM24 26h2v2h-2zM26 28h2v2h-2zM20 30h2v2h-2zM24 30h2v2h-2zM28 30h2v2h-2z"></path>
          </symbol>
          <use xlink:href="#icon-qrcode"></use>
        </svg>
    </div>
    <div class="navfooter">
      <mt-button type="default"size="large" @click.native="start"><span>开始班课</span></mt-button>
    </div>

  </div>
</template>

<script type="text/ecmascript-6">

  import {random_n} from '@/utils/6code'
  export default {
    data() {
      return {
        bankeNum: '',
      }
    },
    created(){
      // todo 自动生成班课号,应该调用后台接口
//      let len = 6;
//      this.bankeNum = ((Number)(Math.random()*9*10**len)+10**len).toString().substr(0,len);
      this.bankeNum = random_n(6);
      console.log(this.bankeNum);
    },
    methods:{
      start(){
        console.log('开始班课')
        this.$router.push('/home')
      }
    }
  }
</script>
<style scoped>
  #bankeQRCode{
    /*background-color: #42b983;*/
    height: 100%;
    width: 100%;
    position: fixed;
  }
  .navheader {
    width: 100%;
    height: 5%;
  }
  .navheader .mint-header{
    /*background-color: #e91e63;*/
    width: 100%;
    height: 100%;
  }
  /*#bankeQRCode .mint-header{*/
    /*width: 100%;*/
    /*!*height: 5%;*!*/
    /*!*margin: 0px 300px 0px 0px;*!*/
    /*!*background-color: #dc3958;*!*/
  /*}*/

  .content{
    /*background-color: #ffda44;*/
    text-align: center;
    width: 100%;
    height: 90%;
    margin: 0px;
  }
  .content svg{
    color: green;
    margin: 20px;
  }
  .icon {
    display: inline-block;
    width: 1em;
    height: 1em;
    stroke-width: 0;
    stroke: currentColor;
    fill: currentColor;
    margin-top: 10px;
  }
  .navfooter {
    /*background-color: #e91e63;*/
    /*margin-bottom: 100px;*/
    width:100%;
    height: 5%;
  }
  .navfooter .mint-button span{
    height: 100%;
    width: 100%;
    font-size:16px;
    color: red;
  }
</style>
