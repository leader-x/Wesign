<template>
  <div id="joinClass">
    <link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
    <mt-header class="header" title="微签" style="background-color:#2bc4e2">
      <router-link to="/createClass" slot="left">
        <mt-button icon="back">加入班课</mt-button>
      </router-link>
    </mt-header>
    <div class="content">
      <div class="detail" >
        <svg class="icon icon-gnu" font-size="150px"><use xlink:href="#icon-gnu"></use></svg><br/>
        <p>{{grade}}<br/>{{courseName}}</p>
        <mt-cell :title="`老师  ${teacher}`" :disabled=true></mt-cell>
        <mt-cell :title="`类型  ${type}`" :disabled=!show></mt-cell>
      </div>
      <mt-button size="large" @click="join()">加入</mt-button>

    </div>
  </div>
</template>

<script type="text/ecmascript-6">

  export default {
    data() {
      return {
        value: '',
        show:false,
        classId: '',
        grade: '傻儿子',
        courseName: '哈哈哈',
        teacher: '池老表',
        type: '学校课标班课',
      }
    },
    created(){
      //TODO 通过传过来的班课号去后台的班课详情
      this.classId = this.$route.params.classId;
      console.log(this.classId);
      //使用classId去后台查询班课详情
    },
    methods:{
      join(){
        console.log('join成功:',this.classId)
        this.$router.push({
          name: 'classDetail',
          params:{
            grade: this.grade,
            courseName: this.courseName
          }
        })

      },
    }
  }
</script>
<style scoped>
  #joinClass{
    /*background-color: #e91e63;*/
    width: 100%;
    position: fixed;
  }
  .header{
    /*background-color: #e91e63;*/
    width: 100%;
  }
  .detail .mint-cell{
    /*background-color: green;*/
    width: 100%;
    text-align: left;
    position: relative;
  }
  .content .mint-button{
    color: #00B7FF;
    margin-top: 100px;
  }

</style>
