<template>
  <div id="exam">
    <link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
    <mt-header class="header" title="微签" style="background-color:#2bc4e2">
      <router-link to="/createClass" slot="left">
        <mt-button icon="back">加入班课</mt-button>
      </router-link>
      <mt-button slot="right" @click="next(value)">下一步</mt-button>
    </mt-header>
    <div class="content">
      <mt-field  placeholder="请输入班课号"
                 type="number" rows="1" v-model="value">
      </mt-field>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">

  export default {
    data() {
      return {
        value: '',
      }
    },
    methods:{
      next(item){
        console.log('next:'+item);
        //TODO 从后台接受，验证班课号是否合法
        //如果合法
        this.$router.push({
          name: 'joinClass',
          params:{
            classId: item
          }
        });
        //否则提示
//
//        this.$router.push({
//          path: '/createClass',
//          query:{
//            exam: item
//          }
//        });
      }
    }
  }
</script>
<style scoped>
  #exam{
    /*background-color: #e91e63;*/
    width: 100%;
    position: fixed;
  }
  .header{
    /*background-color: #e91e63;*/
    width: 100%;
  }

</style>
