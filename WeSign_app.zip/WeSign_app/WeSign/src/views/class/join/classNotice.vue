<template>
  <div id="notice">
    <link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
    <mt-header class="header" title="微签">
      <router-link to="/classDetail" slot="left">
        <mt-button icon="back">班课通知</mt-button>
      </router-link>
    </mt-header>
    <div class="content">
      <p>通知：<br/>
        五一假期课程调整如下:<br/>
        4.27周六放假一天，4.28周日补周四的课，4.29，4.30正常上课，5.1至5.4日放假四天，5.5补周五的课
      </p>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">

  export default {
    data() {
      return {
        value: '',
        show:false,
        classId: '',
        grade: '傻儿子',
        courseName: '哈哈哈',
        teacher: '池老表',
        type: '学校课标班课',
      }
    },
    created(){
      //TODO 通过传过来的班课号去后台的班课详情
      this.classId = this.$route.params.classId;
      console.log(this.classId);
      //使用classId去后台查询班课详情
    },
    methods:{
      join(){
        console.log('join成功:',this.classId)
        this.$router.push({
          name: 'classDetail',
          params:{
            grade: this.grade,
            courseName: this.courseName
          }
        })

      },
    }
  }
</script>
<style scoped>
  #notice{
    /*background-color: #e91e63;*/
    width: 100%;
    position: fixed;
  }
  .header{
    /*background-color: #e91e63;*/
    width: 100%;
  }
  .detail .mint-cell{
    /*background-color: green;*/
    width: 100%;
    text-align: left;
    position: relative;
  }
  .content .mint-button{
    color: #00B7FF;
    margin-top: 100px;
  }

</style>
