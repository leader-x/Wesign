<template>
  <div class="wrapper">
    <link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
    <mt-header title="微签">
      <router-link to="" slot="left">
        <mt-button icon="back" @click="goBack">{{courseName}}</mt-button>
      </router-link>
    </mt-header>
    <!--<div class="block"></div>-->
    <!--<nav-bread></nav-bread>-->
    <div>
    </div>
    <class-footer :selectedBar="selectedBar"></class-footer>
  </div>
</template>

<script>
  import axios from 'axios'
  //  import MuseUI from 'muse-ui';
  //  import 'muse-ui/dist/muse-ui.css';
  import NavHeader from '@/components/header'
  import classFooter from '@/components/classFooter'
  import NavBread from '@/components/bread'

  export default {
    data() {
      return {
        selectedBar: 'first',
        courseName: ''
      }
    },
    components: {
      NavHeader,
      classFooter,
      NavBread
    },
    created(){
      this.courseName = this.$route.query.courseName;
      console.log(this.courseName)
    },
    mounted(){
      console.log(this.$route.query.courseName)
    },
    methods:{
      goBack(){
        console.log('back')
        this.$router.push('/home')
      }
    }
  }

</script>

<style scoped>
  .wrapper {
    width: 100%;
    position: fixed;
    margin: 0px;

    /*.block {*/
    /*height: 4.5rem;*/
    /*}*/
  }
</style>
