<template>
  <div id="joinClass">
    <link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
    <mt-header class="header" title="微签">
      <router-link to="/classDetail" slot="left">
        <mt-button icon="back">签到</mt-button>
      </router-link>
    </mt-header>
    <div class="content">
      <div class="sign" v-show="role=='1'">
        <mt-cell title="选择签到方式"><span style="color: blue">签到方式说明</span></mt-cell>
        <mt-cell-swipe class='sign_type'>
          <div class="sign_type">
            <svg class="icon icon-user-check" font-size="40px" @click="one_click_sign()" color="#a31515"><use xlink:href="#icon-user-check"></use>
              <!--<defs>-->
              <!--<symbol id="icon-user-check" viewBox="0 0 32 32">-->
              <!--<title>user-check</title>-->
              <!--<path d="M30 19l-9 9-3-3-2 2 5 5 11-11z"></path>-->
              <!--<path d="M14 24h10v-3.598c-2.101-1.225-4.885-2.066-8-2.321v-1.649c2.203-1.242 4-4.337 4-7.432 0-4.971 0-9-6-9s-6 4.029-6 9c0 3.096 1.797 6.191 4 7.432v1.649c-6.784 0.555-12 3.888-12 7.918h14v-2z"></path>-->
              <!--</symbol>asasd-->
              <!--</defs>-->
            </svg>
            <span>一键签</span>
          </div>
          <div>
            <svg class="icon icon-th-small-outline" font-size="40px" @click="finger_sign()" color="#6641e2"><use xlink:href="#icon-th-small-outline"></use>
              <defs>
                <symbol id="icon-th-small-outline" viewBox="0 0 24 24">
                  <title>th-small-outline</title>
                  <path d="M6 16h-2c-1.104 0-2 0.896-2 2v2c0 1.104 0.896 2 2 2h2c1.104 0 2-0.896 2-2v-2c0-1.104-0.896-2-2-2zM6 20h-2v-2h2v2z"></path>
                  <path d="M6 9h-2c-1.104 0-2 0.896-2 2v2c0 1.104 0.896 2 2 2h2c1.104 0 2-0.896 2-2v-2c0-1.104-0.896-2-2-2zM6 13h-2v-2h2v2z"></path>
                  <path d="M6 2h-2c-1.104 0-2 0.896-2 2v2c0 1.104 0.896 2 2 2h2c1.104 0 2-0.896 2-2v-2c0-1.104-0.896-2-2-2zM6 6h-2v-2h2v2z"></path>
                  <path d="M13 16h-2c-1.104 0-2 0.896-2 2v2c0 1.104 0.896 2 2 2h2c1.104 0 2-0.896 2-2v-2c0-1.104-0.896-2-2-2zM13 20h-2v-2h2v2z"></path>
                  <path d="M13 9h-2c-1.104 0-2 0.896-2 2v2c0 1.104 0.896 2 2 2h2c1.104 0 2-0.896 2-2v-2c0-1.104-0.896-2-2-2zM13 13h-2v-2h2v2z"></path>
                  <path d="M13 2h-2c-1.104 0-2 0.896-2 2v2c0 1.104 0.896 2 2 2h2c1.104 0 2-0.896 2-2v-2c0-1.104-0.896-2-2-2zM13 6h-2v-2h2v2z"></path>
                  <path d="M20 16h-2c-1.104 0-2 0.896-2 2v2c0 1.104 0.896 2 2 2h2c1.104 0 2-0.896 2-2v-2c0-1.104-0.896-2-2-2zM20 20h-2v-2h2v2z"></path>
                  <path d="M20 9h-2c-1.104 0-2 0.896-2 2v2c0 1.104 0.896 2 2 2h2c1.104 0 2-0.896 2-2v-2c0-1.104-0.896-2-2-2zM20 13h-2v-2h2v2z"></path>
                  <path d="M20 2h-2c-1.104 0-2 0.896-2 2v2c0 1.104 0.896 2 2 2h2c1.104 0 2-0.896 2-2v-2c0-1.104-0.896-2-2-2zM20 6h-2v-2h2v2z"></path>
                </symbol>
              </defs>
            </svg>
            <span>指纹签</span>
          </div>
          <div>
            <svg class="icon icon-compose" font-size="40px" @click="manual_sign()" color="#2F9615"><use xlink:href="#icon-compose"></use>
              <defs>
                <symbol id="icon-compose" viewBox="0 0 20 20">
                  <title>compose</title>
                  <path d="M2 4v14h14v-6l2-2v10h-18v-18h10l-2 2h-6zM12.3 3.7l4 4-8.3 8.3h-4v-4l8.3-8.3zM13.7 2.3l2.3-2.3 4 4-2.3 2.3-4-4z"></path>
                </symbol>
              </defs>
            </svg>
            <span>手工签</span>
          </div>
        </mt-cell-swipe>
        <!--<span>一键签到</span><span>手势签到</span><span>手工签到</span>-->
        <mt-button size="large" v-show="role=='1'" @click="close_sign()">结束签到</mt-button>
      </div>
      <mt-button size="large" v-show="role=='2'" @click="sign()" v-bind:disabled="close">开始签到</mt-button>
      <!-- 获取地理位置 -->

      <mt-cell style="text-align: left;width:100%;" title="历史签到记录">
        <span v-show="role=='1'" style="color: blue; " @click="count()">统计</span>
      </mt-cell>
      <!--<mt-cell style="color: #6641e2" v-show="role=='2'" v-for="(item,index) in signRecord_stu" :title="item.sign_date" :key="index"></mt-cell>-->
      <mt-cell style="color: #6641e2" v-for="(item,index) in signRecord_tea" :title="item.sign_date" :key="index" :value="item.sign_count+'人'"></mt-cell>
    </div>
  </div>
</template>

<script type="text/javascript" src="http://api.map.baidu.com/api?v=3.0&ak=Edx9hGQjnu888GPNu9CrdwM1OywSKa9T"></script>

<script type="text/ecmascript-6">

  import {getCurrentCityName} from '@/utils/getUserLocation'
  export default {
    data() {
      return {
        value: '',
        show:false,
        classId: '',
        totalCount: 0,
        role: '',
        nowTime: '',
        date: "",
        time: "",
        week: "",
        close: false,
        signRecord_stu:[],
        signRecord_tea:[
          {
            sign_date:'2019-04-28 14:30',
            sign_count:12,
          },
          {
            sign_date:'2019-07-06 15:30',
            sign_count:15,
          }
          ],
        sign_count: 0,
      }
    },
    created(){
      //TODO 通过传过来的班课号去后台的班课详情
      this.classId = this.$route.params.classId;
//      console.log(this.classId);
      //使用classId去后台查询班课详情
      //TODO 获取后台用户角色
    },
    mounted(){
//      this.nowTimes();
      this.role = JSON.parse(localStorage.getItem('userInfo')).role
    },
    methods:{
      //获取当前时间
      getDay:function(num) {
        var today = new Date();
        var nowTime = today.getTime();
        var ms = 24 * 3600 * 1000 * num;
        today.setTime(parseInt(nowTime + ms));
        var oYear = today.getFullYear();
        var oMoth = (today.getMonth() + 1).toString();
        if (oMoth.length <= 1) oMoth = '0' + oMoth;
        var oDay = today.getDate().toString();
        if (oDay.length <= 1) oDay = '0' + oDay;
        var oHour = today.getHours().toString()
        if (oHour.length <= 1) oHour = '0' + oHour;
        var oMinutes = today.getMinutes().toString()
        if (oMinutes.length <= 1) oMinutes = '0' + oMinutes;
        return oYear + "-" + oMoth + "-" + oDay+" "+ oHour+":"+oMinutes;
      },
      sign(){
        console.log('开始签到:',this.classId);
        //TODO 先获取老师是否开启签到，只有开启才能签到，签到成功，签到记录+1
        this.nowTime = this.getDay(0)
        console.log(this.signRecord_tea[this.signRecord_tea.length-1].sign_date)
        if(this.nowTime == this.signRecord_tea[this.signRecord_tea.length-1].sign_date){
          this.signRecord_tea[this.signRecord_tea.length-1].sign_count+=1;
        }else {
          this.signRecord_tea.push({'sign_date':this.nowTime, 'sign_count': this.sign_count+1})
        }
      },
      /*获取地图定位*/

      one_click_sign(){
        console.log('一键签到')
        this.close = false;
      },
      finger_sign(){
        console.log('指纹签到')
      },
      manual_sign(){
        console.log('手工签到')
      },
      close_sign(){
        console.log('结束签到')
        this.close = true
      },
      // 教师端统计签到人数
      count(){
        //TODO 统计总签到人数
        console.log('总共签到%d人', this.totalCount)
      },
    },

  }
</script>
<style scoped>
  #joinClass{
    /*background-color: #e91e63;*/
    width: 100%;
    position: fixed;
  }
  .header{
    /*background-color: #e91e63;*/
    width: 100%;
  }
  .content{
    text-align: left;
  }
  .content .mint-button{
    color: #00B7FF;
    /*#00B7FF*/
    /*margin-top: 100px;*/
  }
  .icon {
    display: inline-block;
    width: 1em;
    height: 1em;
    stroke-width: 0;
    stroke: currentColor;
    fill: currentColor;
    margin-left: 30px;
    margin-right: 50px;
  }
  .content span{
    margin-left: 25px;
  }
  .sign_type{
    width: 100%;
    height: auto;
  }
  .mint-cell{
    width: 100%;
    height: 20%;
  }
  .mint-button{
    width: 100%;
    height: 20%;
  }


</style>
