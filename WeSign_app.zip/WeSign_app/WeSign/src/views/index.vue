<template>
  <div id="index">
    <div class="top">
      <link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
      <mt-header title="微签">
        <router-link to="register" slot="right">
          <mt-button>跳过</mt-button>
        </router-link>
      </mt-header>
    </div>
    <div class="content">
      <mt-swipe :auto="0">
        <mt-swipe-item class="slide1">1
          <!--<img src="/static/images/login.jpg">-->
        </mt-swipe-item>
        <mt-swipe-item class="slide2">
          <mt-button @click="gotoLogin">登录</mt-button>
          <mt-button  @click="gotoRegister">注册</mt-button>
        </mt-swipe-item>
      </mt-swipe>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">

  export default {
    data() {
      return {
        msg: '',
      }
    },
    methods:{
      gotoLogin(){
        this.$router.push('/mLogin')
      },
      gotoRegister(){
        this.$router.push('/register')
      }
    }
  }
</script>
<style scoped>
  #index{
    width: 100%;
    height: 100%;
    position: fixed;
    top: 0;
    bottom: 0;
    left: 0;
    background-image: url("/static/images/background.jpg");
  }
  .top{
    width: 100%;
    height: 5%;
  }
  .content{
    /*background-color: green;*/
    width: 100%;
    height: 95%;
    top: 0;
    bottom: 0;
    left: 0;
  }
  .content .mint-button{
    color: red;
    width: 150px;
    top: 500px;
    margin-left: 10px;
    margin-right: 10px;
  }

</style>
