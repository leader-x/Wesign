<template>
  <div>
    <label>课程ID：</label>
    <input type="text" v-model="courseId" value="课程信息"/>
    <mt-button @click="getCourse()">获取</mt-button>
    <textarea></textarea>
  </div>
</template>

<script type="text/ecmascript-6">

  import axios from 'axios'
  export default {
    data() {
      return {
        msg: '',
        courseId: '',
      }
    },
    methods:{
      getCourse(){
        console.log('获取课程', this.courseId)
        axios.get('api/course',{
          id:this.courseId
        }).then((response) => {
          let res = response.data;
          if(res.status == "0"){ // 登录成功
            this.$router.push({path: "/Home"});
          }else {
//            this.errorTip = true;
          }
        });

//        this.$ajax({
//          method: 'get',
//          url: '/api/course?id=1',
//        }).then((response) => {
//          console.log(response.data)
//        }).catch((err) =>{
//          console.log(err)
//        });

      }
    },
  }
</script>
<style scoped>

</style>
