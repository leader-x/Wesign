<template>
  <div></div>
</template>

<script type="text/ecmascript-6">

  export default {
    data() {
      return {
        msg: '',
      }
    }
  }
</script>
<style scoped>

</style>
