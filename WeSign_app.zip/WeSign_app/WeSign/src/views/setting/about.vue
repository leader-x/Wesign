<template>
  <div id="about">
    <mt-header title="微签" style="background-color:#2bc4e2">
      <router-link to="/setting" slot="left">
        <mt-button icon="back">关于我们</mt-button>
      </router-link>
      <mt-button icon="more" slot="right" @click="more"></mt-button>
    </mt-header>
    <div>
      <mt-cell>
        <img slot="icon" src="/static/images/qq.png" style="margin: 10px 0px 0px 0px"/>
      </mt-cell>
      <mt-cell
        title="更新日志"
        is-link></mt-cell>
    </div>
    <div>
      <footer class="footer">
        <div>
          <p>Copyrights © 2018-{{ jzCurrentYear }} FuZhou University #405 Technology Group. All Rights Reserved.</p>
        </div>
      </footer>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">

  export default {
    data() {
      var copyright = new Date()
      var update = copyright.getFullYear()
      return {
        jzCurrentYear: update
      }
    },
    methods:{
      more(){

      }
    }
  }
</script>
<style scoped>
  #about{
    /*background-color: #e91e63;*/
    position: relative;
    margin: 0px -2px 0px -8px;
  }
  p {
    font-size: 1.0rem;
    margin: auto;
    color: #3d3d3d;
  }
  .footer{
    position: relative;
    margin-top:150px;
  }

</style>
