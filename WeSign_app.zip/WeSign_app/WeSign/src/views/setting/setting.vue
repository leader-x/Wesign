<template>
  <div id="setting">
    <mt-header title="微签">
      <router-link :to="{path:'/home',query:{selected:'forth'}}" slot="left">
        <mt-button icon="back">设置</mt-button>
      </router-link>
      <mt-button icon="more" slot="right"></mt-button>
    </mt-header>
    <form class="settingForm">
      <mt-cell
        title="缓存管理"
        to="/"
        is-link>
      </mt-cell>
      <mt-cell
        title="下载管理"
        to="/"
        is-link
        value="">
      </mt-cell>
      <mt-cell
        title="新消息通知"
        to="/"
        is-link
        value="">
      </mt-cell>
      <mt-cell
        title="检查更新"
        to="/"
        is-link
        value="">
      </mt-cell>
      <mt-cell
        title="关于我们"
        to="/about"
        is-link
        value="">
      </mt-cell>
      <mt-cell
        title="留言反馈"
        is-link
        value="">
      </mt-cell>
    </form>
    <mt-button type="danger" size="large" @click.native="logout">退出当前账号</mt-button>
  </div>
</template>

<script type="text/ecmascript-6">

  import {setCookie, getCookie, delCookie} from '@/assets/js/cookie'

  export default {
    data() {
      return {
        name: '',
      }
    },
    methods:{
      logout(){
        let uname = getCookie('username')
        console.log(uname)
        //删除cookie
        delCookie(uname)
        this.$router.push('/mlogin');
      }
    }
  }
</script>
<style scoped>
  #setting{
    width: 100%;
    height: 100%;
    top: 0;
    bottom: 0;
    left: 0;
    /*margin: 0px 32px 0px -8px;*/
    position: fixed;
  }
  .settingForm{
    /*background-color: #E1E1E1;*/
    width: 100%;
    position: relative;
    padding: 0px;
    /*margin: 0px 85px 0 0px;*/
  }
  .mint-cell{
    background-color: #f5f7f9;
    width: 100%;
    padding: 1px;
    text-align: left;
    margin-top: 10px;
    /*margin: 10px 230px 0 0px;*/
  }

</style>
