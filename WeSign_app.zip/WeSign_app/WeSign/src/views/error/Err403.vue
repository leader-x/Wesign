<template>
  <div class="error-page">
      <!--<img class="err-img " src="./../assets/images/403_1.png" />-->
    <div class="error-code">4<span>0</span>3</div>
    <div class="error-desc">抱歉~ 您没有权限访问该页面哦</div>
    <div class="error-handle">
      <router-link to="/">
        <mt-button type="primary" size="small">返回首页</mt-button>
      </router-link>
      <mt-button class="error-btn" type="primary" size="small" @click="goBack">返回上一页</mt-button>
    </div>
  </div>
</template>

<script>

  export default {
    name: 'Err403',
    methods: {
      goBack(){
        this.$router.go(-1);
      }
    }
  }
</script>


<style scoped>
  .error-page{
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    width: 100%;
    height: 100%;
    background: #f3f3f3;
    box-sizing: border-box;
  }
  .err-img{
    width: 300px;
    height: 300px;
    margin: left;
  }
  .error-code{
    line-height: 1;
    font-size: 200px;
    font-weight: bolder;
    color: #f02d2d;
  }
  .error-code span{
    color: #00a854;
  }
  .error-desc{
    font-size: 20px;
    color: #777;
  }
  .error-handle{
    margin-top: 30px;
    padding-bottom: 200px;
  }
  .error-btn{
    margin-left: 10px;
  }
</style>
