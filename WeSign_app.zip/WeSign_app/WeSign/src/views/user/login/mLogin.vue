<template>
  <div id="login">
    <div class="login-wrap" v-show="showLogin">
      <h3>登录</h3>
      <p v-show="showTishi">{{tishi}}</p>
      <!--<svg-icon icon-class="user" style="font-size: 25px"></svg-icon>-->
      <input type="text" placeholder="请输入用户名" v-model="userName"><br/>
      <!--<svg-icon icon-class="password" style="font-size: 25px"></svg-icon>-->
      <input type="password" placeholder="请输入密码" v-model="password">
      <button @click="login">登录</button>
      <ul class="account-list" style="margin-right: 30px">
          <!--https://graph.qq.com/oauth2.0/authorize?response_type=code&client_id=101512648&redirect_uri=http://www.lovemtt.com/qq&state=qq-->
          <a href="https://graph.qq.com/oauth2.0/authorize?response_type=code&client_id=101512648&redirect_uri=http://www.lovemtt.com/qq&state=qq"
             style="{right: 26px;}">
            <!--<img class="icon" src="/static/images/social-qq.svg" style="height: 26px" />-->
            <svg-icon icon-class="social-qq" style="font-size: 20px;margin-right: 5px"></svg-icon>
          </a>
          <a href="https://open.weixin.qq.com/connect/qrconnect?appid=wx827225356b689e24&state=D60CB1418E02A86A73408390D4DC26587AC73F7A9A0B3F86F17CD45E88B93B358DE684C2B811C67A04707E6EB149E463&redirect_uri=https%3A%2F%2Fqq.jd.com%2Fnew%2Fwx%2Fcallback.action%3Fview%3Dnull%26uuid%3Dcf7618b3e1ef4840ab9cb83664923e5b&response_type=code&scope=snsapi_login#wechat_redirect"
             style="{right: 26px;}">
            <svg-icon icon-class="wechat" style="font-size: 20px;color: green;margin-left: 5px"></svg-icon>
          </a>
        <a href="javascript:;"
           style="{right: 26px;}">
          <svg-icon icon-class="sinaweibo" style="font-size: 20px;margin-left: 5px"></svg-icon>
        </a>
        <span v-on:click="ToRegister" style="color: blue">没有账号？马上注册</span>
      </ul>
    </div>

    <div class="register-wrap" v-show="showRegister">
      <h3>注册</h3>
      <p v-show="showTishi">{{tishi}}</p>
      <input type="tel" placeholder="请输入手机号" v-model="newPhone" maxlength="11" onkeyup="value=value.replace(/[^\d]/g,'')"
             required pattern="^((13[0-9])|(14[5|7])|(15([0-3]|[5-9]))|(18[0,3,5-9]))\d{8}$">
      <span required>请输入手机号</span>
      <span>手机号码格式不正确</span>
        <input type="number" placeholder="请输入验证码" v-model="code" oninput="if(value.length>5)value=value.slice(0,5)">
        <span>验证码不正确</span>
        <a id="vercode" href="javascript:;" @click="sendMessage" >{{btnText}}</a>
        <!--<span class="time" v-show="show"><em>{{timeStamp}}</em>s</span>-->
        <!--<span class="tel-warn error hide">验证码错误</span>-->
      <!--<div class="red sendCode" @click="sendMessage">{{btnText}}</div>-->

      <input type="text" placeholder="请输入用户名" v-model="newUsername">
      <span>用户名不能为空</span>
      <span>用户名已存在</span>
      <input type="password" placeholder="请输入密码" v-model="newPassword">
      <span>密码不能为空</span>
      <span>密码必须为9位数字加字符</span>
      <input type="email" placeholder="请输入邮箱" v-model="newEmail">
      <span>邮箱格式不正确</span>
      <button v-on:click="register">注册</button>
      <span v-on:click="ToLogin" style="color: blue">已有账号？马上登录</span>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import {setCookie, getCookie} from '@/assets/js/cookie'
  import axios from 'axios'
 import {MessageBox} from 'mint-ui'

  export default {
    data() {
      return{
        showLogin: true,
        showRegister: false,
        showTishi: false,
        tishi: '',
        userInfo: {},
        userName: '',
        password: '',
        newUsername: '',
        newPassword: '',
        newPhone: '',
        newEmail: '',
        code: '',
        btnDisabled:false,
        btnText:'发送验证码'
      }
    },
    mounted(){
      /*页面挂载获取cookie，如果存在username的cookie，则跳转到主页，不需登录*/
      this.tishi = ''
      if(getCookie('userName')){
        this.$router.push('/home')
      }
    },
    methods:{
      ToLogin(){
        this.showRegister = false
        this.showLogin = true
      },
      login(){
        if(this.userName == "" || this.password == ""){
          this.$toast({
            message: '用户名或密码不能为空',
            position: 'bottom',
            iconClass: 'icon icon-err',
            duration: 3000
          });
        }else {
          let data = {'username':this.userName,'password':this.password}
          // 接口请求
          axios.post('/users/login',data).then((result) => {
            let res = result.data
            console.log(res)
            if(res.status == '-1'){
              console.log(res.msg)
            } else if(res.status == '1'){
              console.log(res.msg)
              this.showTishi = true
//              this.tishi = res.msg
              MessageBox.alert(res.msg).then(action => {
                this.userName = ''
                this.password = ''
              });
            }else {
//              this.tishi = '登陆成功'
              this.showTishi = true
              console.log(res.result)
              this.userInfo = {userName: this.userName, password: this.password, role: res.result.list.role}
              localStorage.setItem('userInfo', JSON.stringify(this.userInfo))
              setCookie('username',this.userName, 1000*60)
//              MessageBox.alert('提示', '操作成功').then(action => {
//                this.$router.push('/home')
//              });
              setTimeout(function () {
                this.$router.push('/home')
              }.bind(this),1000)
            }
          });
        }
      },
      ToRegister(){
        this.showRegister = true
        this.showLogin = false
      },
      register(){
        if(this.newUsername == "" || this.newPassword == ""){
          this.showTishi = true
          this.tishi = '用户名或密码不能为空'
        }else{
          let data = {'username':this.newUsername,'password':this.newPassword,'role':1}
          axios.post('/users/register',data).then((result)=>{
            let res = result.data
            console.log(res)
            if(res.status == "-1"){
              console.log(res.msg)
            }else {
              this.showTishi = true
              this.tishi = "注册成功"
              this.userName = ''
              this.password = ''
              /*注册成功之后再跳回登录页*/
              setTimeout(function(){
                this.showRegister = false
                this.showLogin = true
                this.showTishi = false
              }.bind(this),1000)
            }
          })
        }
      },
      sendMessage(){
        console.log('发送验证码')
        if(this.btnDisabled){
          return;
        }
        this.getSecond(60);
      },
      //发送验证码
      getSecond(wait){
        let _this=this;
        let _wait = wait;
        if(wait == 0) {
          this.btnDisabled=false;
          this.btnText="发送验证码"
          wait = _wait;
        } else {
          this.btnDisabled=true;
          this.btnText="重新发送(" + wait + "s)"
          wait--;
          setTimeout(function() {
              _this.getSecond(wait);
            },
            1000);
        }
      },

    }
  }
</script>
<style scoped>
  #login{
    /*color: green;*/
    width: 100%;
    height: 100%;
    top: 0;
    bottom: 0;
    left:0;
    position: fixed;
    background-image: url("/static/images/login.jpg");
  }
  .login-wrap{
    text-align:center;
    width: 100%;
    height: 100%;
  }
  input{
    display:block;
    width:250px;  height:40px;
    line-height:40px;
    margin:10px auto; margin-bottom: 10px;
    outline:none;
    border:1px solid #888; padding:10px;
    box-sizing:border-box;
  }
  p{color:red;}
  h3{color: blue}
  button{
    display:block;
    width:250px; height:40px; line-height: 40px;
    margin:0 auto ; border:none;
    background-color:#41b883; color:#fff;
    font-size:16px; margin-bottom:5px;
  }
  span{
    cursor:pointer;
    color: red;
    font-size: 12px
  }
  span:hover{
    color:#41b883;
  }
  /*.sendCode{*/
    /*width: auto;*/
    /*border: 0;*/
    /*!*outline: none;*!*/
    /*background-color: #fff;*/
    /*!*cursor: pointer;*!*/
  /*}*/
  /*svg {*/
    /*display: inline-block;*/
    /*width: 1em;*/
    /*height: 1em;*/
    /*stroke-width: 0;*/
    /*stroke: currentColor;*/
    /*fill: currentColor;*/
  /*}*/

</style>
