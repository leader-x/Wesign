<template>
  <div id="reset">
    <mt-header title="微签">
      <router-link to="/" slot="left">
        <mt-button icon="back">首页</mt-button>
      </router-link>
    </mt-header>
    <form class="pwd-page" name="pwdForm">
      <h3>找回密码</h3>
      <p class="right_now">已有账号，<router-link to="/mLogin">马上登录</router-link></p>
      <input type="number" placeholder="请输入手机号" v-model="phoneNum"
             oninput="if(value.length>11) value=value.slice(0,11)">
             <!--onblur="isPhone(this.value);">-->
         <!--maxlength="11" required onkeyup="value=value.replace(/[^\d]/g,'')" pattern="^((13[0-9])|(14[5|7])|(15([0-3]|[5-9]))|(18[0,3,5-9]))\d{8}$">-->
      <span v-show="showPhone">{{phoneMsg}}</span>
      <input type="number" placeholder="请输入验证码" v-model="vercode" oninput="if(value.length>6)value=value.slice(0,6)">
      <span v-show="showCode" required>{{codeMsg}}</span>
      <a id="vercode" href="javascript:;" @click="sendMessage" >{{btnText}}</a>
      <input type="password" placeholder="请输入密码" v-model="newPwd">
      <span v-show="showNewPwd" required>{{pwdMsg}}</span>
      <input type="password" placeholder="确认密码" v-model="confirmPwd">
      <span v-show="showConfirmPwd">{{confirmPwdMsg}}</span>
      <div class="btn">
        <button v-on:click="cancel">重置</button>
        <button v-on:click="confirm">提交</button>
      </div>
    </form>

  </div>
</template>

<script type="text/ecmascript-6">

  export default {
    data() {
      return {
        phoneNum: '',
        vercode: '',
        newPwd: '',
        confirmPwd:'',
        showPhone: false,
        phoneMsg: '',
        showCode: false,
        codeMsg: '',
        showNewPwd: false,
        pwdMsg: '',
        showConfirmPwd: false,
        confirmPwdMsg: '',
        btnDisabled:false,
        btnText:'发送验证码'
      }
    },
    methods:{
      sendMessage(){
        console.log('发送验证码')
        if(this.btnDisabled){
          return;
        }
        this.getSecond(60);
      },
      //发送验证码
      getSecond(wait){
        let _this=this;
        let _wait = wait;
        if(wait == 0) {
          this.btnDisabled=false;
          this.btnText="发送验证码"
          wait = _wait;
        } else {
          this.btnDisabled=true;
          this.btnText="重新发送(" + wait + "s)"
          wait--;
          setTimeout(function() {
              _this.getSecond(wait);
            },
            1000);
        }
      },
      cancel(){
        console.log('cancel')
        this.phoneNum = ''
        this.vercode = ''
        this.newPwd = ''
        this.confirmPwd = ''
      },
      confirm(){
        console.log('confirm',this.phoneNum)
        //TODO 判断是否合法，正确则返回登录
        const self = this
        if (self.phoneNum == "" || !self.phoneNum){
          console.log("请输入手机号码");
          self.showPhone = true
          self.phoneMsg = "手机号码不能为空"
//          self.$toast({
//            message: "请输入电话号码",
//            position: "bottom"
//          });
        } else if(!(/^1[34578]\d{9}$/.test(self.phoneNum))){
          console.log("手机号码格式错误");
          self.showPhone = true
          self.phoneMsg = "手机号码格式错误"
//          self.$toast({
//            message: "电话号码格式错误",
//            position: "bottom"
//          });
        }else if(self.vercode =="" || !self.vercode){
          console.log("验证码不能为空");
          self.showPhone = false
          self.showCode = true
          self.codeMsg = "验证码不能为空"
        }
        //TODO 验证获取到的验证码
        else if(self.newPwd =="" || !self.newPwd){
          console.log("请输入新密码");
          self.showPhone = false
          self.showCode = false
          self.showNewPwd = true
          self.pwdMsg = "请输入新密码"
        }else if(!(/^[A-Za-z0-9]{1,9}$/.test(self.newPwd))){
          console.log("密码格式错误");
          self.showNewPwd = true
          self.pwdMsg = "密码必须为9位数字加字符"
        }else if(self.confirmPwd =="" || !self.confirmPwd){
          console.log("请输入确认密码");
          self.showPhone = false
          self.showCode = false
          self.showNewPwd = false
          self.showConfirmPwd = true
          self.confirmPwdMsg = "请输入确认密码"
        }else if (self.newPwd != self.confirmPwd){
          console.log("两次输入密码不一致");
          self.confirmPwdMsg = "两次输入密码不一致"
        }else {
          self.showConfirmPwd = false
          //TODO 调用后端接口验证输入信息同时将信息传给后台
          this.$router.push('/mLogin')
        }
      },
    }
  }
</script>
<style scoped>
  #reset{
    background-color: #f6f6ae;
    width: 100%;
    height: 100%;
    top: 0;
    bottom: 0;
    left: 0;
    position: fixed;
  }
  .pwd-page{
    /*background-color: green;*/
    /*margin-top: 100px;*/
    top: 0;
  }
  input{
    display:block;
    width:240px;  height:30px;
    line-height:30px;
    margin:10px auto; margin-bottom: 10px;
    outline:none;
    border:1px solid #888; padding:10px;
    box-sizing:border-box;
  }
  p{color:blue;font-size: 12px}
  a{
    font-size: 12px;
  }
  h3{color: blue}
  .btn{
    display:block;
    width:240px; height:30px;
    margin:0px auto ;
    /*background-color:#41b883;*/
    margin-bottom:5px;
  }
  .btn button{
    width:80px;
    height:30px;
    /*line-height: 30px;*/
    color: blue;
    font-size: 16px;
    margin-left: 10px;
    margin-right: 10px;
  }
  span{
    cursor:pointer;
    color: red;
    font-size: 14px
  }
  span:hover{
    color:#41b883;
  }

</style>
