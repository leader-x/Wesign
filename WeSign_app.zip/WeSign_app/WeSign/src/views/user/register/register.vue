<template>
  <div id="register">
    <!--<div class="page-title">用户注册</div>-->
    <form class="page-main">
      <!--<div class="page-field">-->
        <p style="font-size: 20px;color: blue">用户注册</p>
        <mt-field label="用户名" placeholder="请输入用户名" v-model="userName" :attr="{ maxlength: 10 }"></mt-field>
        <mt-field label="密码" placeholder="请输入密码" type="password" v-model="password"></mt-field>
        <mt-field label="手机号" placeholder="请输入手机号" type="number" :attr="{ maxlength: 11 }" v-model="phone"></mt-field>
        <mt-field label="邮箱" placeholder="请输入邮箱" type="email" v-model="email"></mt-field>
        <mt-field label="生日" placeholder="请输入生日" type="date"></mt-field>

        <mt-field label="验证码" placeholder="输入验证码">
          <img src="/static/images/QR.jpg" height="48px" width="100px">
        </mt-field>
        <mt-button type="primary" size="large" @click="register">注册</mt-button>
        <!--<mt-button type="primary" size="normal">确定</mt-button>-->
      <!--</div>-->
      <!--<div class="page-btn">--><!--</div>-->
    </form>
  </div>
</template>

<script type="text/ecmascript-6">

import {MessageBox} from 'mint-ui'
import axios from 'axios'
  export default {
    data() {
      return {
        userName: '',
        password: '',
        phone: '',
        email: '',
      }
    },
    methods:{
      register(){
        console.log('用户注册');
        if(this.userName == "" || this.password == ""){
//          this.$toast({
//            message: '用户名或密码不能为空',
//            position: 'bottom',
//            iconClass: 'icon icon-err',
//            duration: 3000
//          });
          MessageBox.alert('用户名或密码不能为空!', '提示');
        }else{
          let data = {'username':this.userName,'password':this.password,'phone':this.phone,'email':this.email}
          this.$http.post('/users/login',data).then((res)=>{
            console.log(res)
            if(res.data == "ok"){
              this.tishi = "注册成功"
              this.showTishi = true
              this.username = ''
              this.password = ''
              /*注册成功之后再跳回登录页*/
              setTimeout(function(){
                this.showRegister = false
                this.showLogin = true
                this.showTishi = false
              }.bind(this),1000)
            }
          });

//          axios.post("/users/login",{
//            userName:this.userName,
//            userPwd:this.password
//          }).then((result) => {
//            let res = result.data;
//            if(res.status == "0"){ // 注册成功
//              this.$router.push({path: "/mLogin"});
//            }else {
////            this.errorTip = true;
//            }
//          }).catch((error) => {
//            console.log(error);
//          });
        }
      },
      Toast(msg){
        this.Toast({
          message: msg,
          position: 'bottom',
          duration: 3000
        });
      }
    }
  }
</script>
<style scoped>
  #register{
    background-image: url("/static/images/login.jpg");
    /*color: green;*/
    width: 100%;
    height: 100%;
    position: fixed;
    text-align: center;
    top: 0;
    bottom: 0;
    left: 0;
  }
  .page-main {
    width: 100%;
    height: 100%;
    /*text-align: center;*/
    top: 0;
    bottom: 0;
    left: 0;
    /*padding: 1px;*/
  }
  form{
    margin-top: 100px;
  }
  .mint-button{
    /*padding: 10px;*/
    /*margin: 0px 20px 0px 20px;*/
  }
</style>
