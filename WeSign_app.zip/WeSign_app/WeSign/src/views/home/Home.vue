<template>
  <div id="homePage">
    <nav-header class="navheader"></nav-header>
    <!--<nav-bread></nav-bread>-->
    <!--<div>-->
    <!--</div>-->
    <nav-footer></nav-footer>
  </div>
</template>

<script>
  import axios from 'axios'

//  import MuseUI from 'muse-ui';
//  import 'muse-ui/dist/muse-ui.css';
  import NavHeader from '@/components/header'
  import NavFooter from '@/components/footer'
  import NavBread from '@/components/bread'

  export default {
    data() {
      return {
//        selected: '',
      }
    },
    components: {
      NavHeader,
      NavFooter,
      NavBread
    },
    monuted(){
    },
    methods:{

    }
  }

</script>

<style scoped>
  #homePage .navheader{
    /*height: 100%;*/
    width: 100%;
    position: fixed;
    margin-top: 0px;
  }
    /*.navheader{*/
      /*background-color: #55ffff;*/
      /*position: absolute;*/
    /*}*/

    /*.block {*/
      /*height: 4.5rem;*/
    /*}*/

</style>

