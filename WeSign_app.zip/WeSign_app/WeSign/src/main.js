// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
// import Vuex from 'vuex'
import App from './App'
import router from './router'
import store from './store/store'

//ui库
// import ElementUI from 'element-ui'
// import MuseUI from 'muse-ui'
// import 'muse-ui/dist/muse-ui.css'
import jq from 'jquery'
import Mint from 'mint-ui'
import 'mint-ui/lib/style.css'
import './icons'

import axios from 'axios'

Vue.use(Mint);
Vue.prototype.$ = jq;
Vue.prototype.$ajax = axios;  //修改Vue的原型属性

Vue.config.productionTip = false

// axios配置
axios.defaults.timeout = 5000;
// var axios = require('axios');
axios.defaults.headers.post['Content-Type'] = 'application/json;charset=UTF-8';
// //todo 设置基础URL为后端服务api地址
// axios.defaults.baseURL = 'http://localhost:3000'
// Vue.use(Vuex)
// Vue.use(ElementUI);
// Vue.use(MuseUI);


/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  components: { App },
  template: '<App/>'
})
