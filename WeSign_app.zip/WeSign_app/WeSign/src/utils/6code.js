function random(length) {
  var str = Math.random().toString(36).substr(2);
  // var str = Math.random()*9+1;
  console.log(str)
  if (str.length>=length) {
    return str.substr(0, length);
  }
  str += random(length-str.length);
  return str;

  // let len = 6;
  // ((Number)(Math.random()*9*10**len)+10**len).toString().substr(0,len);
}
// 随机n位验证码
function random_n(len) {
  let str;
  str = ((Math.random()*9*10**len)+10**len).toString().substr(0,len);
  return str;
}
export {
  random,
  random_n
}
