
var http = require('http');

var querystring = require('querystring');

//参数设置
var appid = '1000xxxx';
var appkey = '56cf61af4b7897e704f67deb88ae8f24';
var module = 'getUniversityInfo';

//目标查询院校代码/高等学校或院校名称
var school='武汉大学';

//签名，SHA256 不可直接调用；函数参考下载地址：https://github.com/alexweber/jquery.sha256
var sign = SHA256('appid='+appid+'&module='+module+'&school='+school+'&appkey='+appkey);

//这是需要提交的数据
var post_data = {
  appid: appid,
  module: module,
  school: school,
  sign: sign
};

var content = querystring.stringify(post_data);

var options = {
  hostname: 'cha.ebaitian.cn',
  port: 80,
  path: '/api/json',
  method: 'POST',
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
  }
};

var req = http.request(options, function (res) {
  console.log('STATUS: ' + res.statusCode);
  console.log('HEADERS: ' + JSON.stringify(res.headers));
  res.setEncoding('utf8');
  res.on('data', function (chunk) {
    console.log('BODY: ' + chunk);
    //JSON.parse(chunk)
  });
});

req.on('error', function (e) {
  console.log('problem with request: ' + e.message);
});

// write data to request body
req.write(content);
req.end();
