var header = ['邀请码(随机6位 数字+大小写字母)'];
var content = [];
var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
var codeLength = 6;//单个code长度
var codeListLength = 500;//需要多少个code
var tempCodeList = [];//临时存放code的数组，校验重复数据使用

var generateRandomNum = function(min,max){
  if (max===undefined || min===undefined){
    console.log("必须传入max和min")
    return false;
  };
  let num = Math.floor(Math.random()*(max-min+1)+min);
  return num;
};

var generateCode = function(len){
  len = len || 32;
  var maxPos = chars.length;
  // console.log(maxPos)
  var code = '';
  for (var i = 0; i < len; i++) {
    //0~61的整数
    var randomNum = generateRandomNum(0,maxPos-1);
    var char = chars.charAt(randomNum);
    // console.log(char);
    code += char;
  };
  return code;
};

var generateCodeList = function(len){
  for(var i=0;i<len;i++){
    var code = generateCode(codeLength);
    //校验唯一
    if (tempCodeList.indexOf(code) === -1){
      tempCodeList.push(code);
    }else{
      i--;
    };
  };

  for (var j=0;j<tempCodeList.length;j++){
    var tempList = [];
    tempList.push(tempCodeList[j]);
    content.push(tempList);
  };
};

var doDownload = function(){
  var downloadLink = document.getElementById('downloadLink');
  var context = "";
  var context = header.join(',') + '\n';
  generateCodeList(codeListLength);

  for (var i=0;i<content.length;i++){
    var item = content[i];
    item.forEach(function(item,index,list){
      context = context + item + ','
    })
    context = context + '\n'
  };

  // var context = "col1,\"反反\n复复\",col3\nvalue1,value2,value3"
  // console.log('---------------拼接的字符串---------------\n' + context)
  context = encodeURIComponent(context)
  downloadLink.download = '特权码(' + codeListLength + '个).csv' // 下载的文件名称
  downloadLink.href = "data:text/csv;charset=utf-8,\ufeff" + context; //加上 \ufeff BOM 头
  downloadLink.click();
  return context;
};

export  {
  doDownload
}
