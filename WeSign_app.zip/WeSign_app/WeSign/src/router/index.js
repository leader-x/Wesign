import Vue from 'vue'
import Router from 'vue-router'
import LoginPage from '@/views/LoginPage'
import resertPwdPage from '@/views/resertPwdPage'
// import forgetPassword from '@/views/forgetPassword'



Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'index',
      component: () => import('@/views/index')
    },
    {
      path: '/home',
      name: 'home',
      component: () => import('@/views/home/Home')
    },
    // {
    //   path: '/',
    //   name: 'login',
    //   component: Login
    // },
    {
      path: '/header',
      name: 'header',
      component: () => import('@/components/header')
    },
    {
      path: '/classFooter',
      name: 'classFooter',
      component: () => import('@/components/classFooter')
    },
    {
      path: '/footer',
      name: 'footer',
      component: () => import('@/components/footer')
    },
    // {
    //   path: '/test1',
    //   name: 'test1',
    //   component: () => import('@/views/test/test1')
    // },
    // {
    //   path: '/test2',
    //   name: 'test2',
    //   component: () => import('@/views/test/test2')
    // },
    // {
    //   path: '/test3',
    //   name: 'test3',
    //   component: () => import('@/views/test/test3')
    // },
    // {
    //   path: '/testAPI',
    //   name: 'testAPI',
    //   component: () => import('@/views/testAPI')
    // },
    // {
    //   path: '/test4',
    //   name: 'test4',
    //   component: () => import('@/views/test/test4')
    // },
    /*用户页面*/
    {
      path: '/login',
      name: 'loginPage',
      component: LoginPage
    },
    {
      path: '/mlogin',
      name: 'mlogin',
      component: () => import('@/views/user/login/mLogin')
    },
    // 登录
    {
      path: '/mobLogin',
      name: 'mobLogin',
      component: () => import('@/views/user/login/mLogin')
    },
    // 注册
    {
      path: '/register',
      name: 'register',
      component: () => import('@/views/user/register/register')
    },
    //重置密码
    {
      path: '/resetPassword',
      name: 'resetPassword',
      component: () => import('@/views/user/resetPassword/resetPassword')
    },
    /*班级页面*/
    {
      path: '/createClass',
      name: 'createClass',
      component: () => import('@/views/class/create/createClass')
    },
    {
      path: '/school',
      name: 'school',
      component: () => import('@/views/class/create/school')
    },
    {
      path: '/depart',
      name: 'depart',
      component: () => import('@/views/class/create/depart')
    },
    {
      path: '/study',
      name: 'study',
      component: () => import('@/views/class/create/study')
    },
    {
      path: '/teach',
      name: 'teach',
      component: () => import('@/views/class/create/teach')
    },
    {
      path: '/exam',
      name: 'exam',
      component: () => import('@/views/class/create/exam')
    },
    {
      path: '/createSuccess',
      name: 'createSuccess',
      component: () => import('@/views/class/create/createSuccess')
    },
    {
      path: '/searchClass',
      name: 'searchClass',
      component: () => import('@/views/class/join/searchClass')
    },
    {
      path: '/joinClass',
      name: 'joinClass',
      component: () => import('@/views/class/join/joinClass')
    },
    {
      path: '/classDetail',
      name: 'classDetail',
      component: ()=> import('@/views/class/join/classDetail')
    },
    {
      path: '/classNotice',
      name: 'classNotice',
      component: ()=> import('@/views/class/join/classNotice')
    },
    /*签到页面*/
    {
      path: '/sign',
      name: 'sign',
      component: ()=> import('@/views/sign/sign'),
    },
    /*获取地理位置*/
    {
      path: '/getLocation',
      name: 'getLocation',
      component: ()=> import('@/views/sign/getLocation')
    },
    /*设置页面*/
    {
      path: '/setting',
      name: 'setting',
      component: () => import('@/views/setting/setting')
    },
    {
      path: '/about',
      name: 'about',
      component: () => import('@/views/setting/about')
    },

    /*错误页面*/
    {
      path: '/err/403',
      name: '403',
      component: () => import(/* webpackChunkName: "err" */ './../views/error/Err403.vue')
    },
    {
      path: '/err/404/',
      name: '404',
      component: () => import(/* webpackChunkName: "err" */ './../views/error/Err404.vue')
    },
    {
      path: '/err/500/',
      name: '500',
      component: () => import(/* webpackChunkName: "err" */ './../views/error/Err500.vue')
    },
  ]
})
