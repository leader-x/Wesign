var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var users = require('../models/users');

/* GET users listing. */
router.get('/test', function(req, res, next) {
  res.send('test');
});


router.get('/',function (req, resp, next) {

  console.log(req.query.userName);    // post方法用req.boby.userName
  let params = {
    userName: req.query.userName,
  }
  users.find(params, function (err, doc) {
    if(err){
      resp.json({
        status: '1',
        msg: err.message,
      });
    }else {
      console.log("userRole:" + doc);
      if(doc){
        resp.json({
          status: '0',
          msg: '',
          result: {
            list: doc
          }
        });
      }
    }
  })
});


/*获取用户角色*/
router.get('/getRole',function (req, resp, next) {

  resp.setHeader('Access-Control-Allow-Origin', '*');

  resp.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

  resp.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

  resp.setHeader('Access-Control-Allow-Credentials', true);

  console.log(req.query.userName);    // post方法用req.boby.userName
  let params = {
    userName: req.query.userName,
  }
  users.find(params, function (err, doc) {
    if(err){
      resp.json({
        status: '1',
        msg: err.message,
      });
    }else {
      console.log("userRole:" + doc);
      if(doc){
        resp.json({
          status: '0',
          msg: '',
          result: {
            list: doc
          }
        });
      }
    }
  })
});

router.get('/role',function (req, resp, next) {

  resp.setHeader('Access-Control-Allow-Origin', '*');

  resp.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

  resp.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

  resp.setHeader('Access-Control-Allow-Credentials', true);

  console.log(req.query.userName);    // post方法用req.boby.userName
  let params = {
    userName: req.query.userName,
  }
  users.find(params, function (err, doc) {
    if(err){
      resp.json({
        status: '1',
        msg: err.message,
      });
    }else {
      console.log("userRole:" + doc);
      if(doc){
        resp.json({
          status: '0',
          msg: '',
          result: {
            list: doc
          }
        });
      }
    }
  })
});



/*获取所有用户*/
router.get('/list',function (req,resp,next) {
  users.find({}, function (err, doc) {
    if (err) {
      resp.json({
        status: '1',
        msg: err.message,
      });
    } else {
      console.log("userDoc:" + doc);
      resp.json({
        status: '0',
        msg: '',
        result: {
          count: typeof doc.length == 'undefined' ? 1 : doc.length,
          list: doc
        }
      });
    }
  });
});

/*登录接口*/
router.post('/login',function (req,resp,next) {
  // resp.send("hello,grade list");
  let params = {
    userName: req.body.username,
    password: req.body.password
  }
  console.log(params)
  users.findOne(params,function (err,doc) {
    if(err){
      resp.json({
        status: '-1',
        msg: err.message,
      });
    }else {
      console.log("userDoc:"+doc);
      if(doc){
        resp.json({
          status: '0',
          msg: '',
          result:{
            count: typeof doc.length == 'undefined'?1:doc.length,
            list:doc
          }
        });
      }else {
        resp.json({
          status: '1',
          msg: '用户名或密码不正确',
        });
      }

    }
  })
});

router.post('/register',function (req,resp,next) {
  // resp.send("hello,grade list");
  var params = {
    userName:req.body.username,
    password:req.body.password,
    role: req.body.role
  }
  console.log(params)
  users.create(params,function (err,doc) {
    if(err){
        resp.json({
        status:'-1',
        msg:err,message,
        result:''
      });
    }else {
      resp.json({
        status:'0',
        msg:'',
        result:{
          list: {
           userName: params.userName,
           password: params.password,
            role: params.role
          }
        }
      });
    }
  })
});

module.exports = router;
