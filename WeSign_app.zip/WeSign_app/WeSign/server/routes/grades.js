var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var grades = require('../models/grades');

//连接MongoDB数据库
mongoose.connect('mongodb://127.0.0.1:27017/test');

mongoose.connection.on("connected", function () {
  console.log("MongoDB connected success.")
});

mongoose.connection.on("error", function () {
  console.log("MongoDB connected fail.")
});

mongoose.connection.on("disconnected", function () {
  console.log("MongoDB connected disconnected.")
});

router.get("/",function (req,resp,next) {
  // resp.send("hello,grade list");
  grades.find({},function (err,doc) {
    if(err){
      resp.json({
        status: '1',
        msg: err.message,
      });
    }else {
      console.log(typeof doc.length == 'undefined');
      resp.json({
        status: '0',
        msg: '',
        result:{
          count: typeof doc.length == 'undefined'?1:doc.length,
          list:doc
        }
      });
    }
  })
});

module.exports = router;
