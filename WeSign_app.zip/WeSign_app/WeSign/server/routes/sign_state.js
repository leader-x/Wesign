var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var sign_state = require('../models/sign_state');

/* GET users listing. */
router.get('/test', function(req, res, next) {
  res.send('test');
});

router.get('/',function (req,resp,next) {
  // resp.send("hello,grade list");
  // console.log(typeof req.query.userName == 'undefined')
  var params = {teacher_name: req.query.teacher_name}
  console.log(params)
  sign_state.find(params,function (err,doc) {
    if(err){
      resp.json({
        status: '1',
        msg: err.message,
      });
    }else {
      console.log(typeof doc.length == 'undefined');
      resp.json({
        status: '0',
        msg: '',
        result:{
          count: typeof doc.length == 'undefined'?1:doc.length,
          list:doc
        }
      });
    }
  })
});


module.exports = router;
