var mongoose = require('mongoose')
var Schema = mongoose.Schema;

var signSchema = new Schema({
  // "id": String,
  "teacher_name": String,
  "class_id": String,
  "count": Number,
  "state": String
});

module.exports = mongoose.model('Sign_state',signSchema);
