var mongoose = require('mongoose')
var Schema = mongoose.Schema;

var studentSchema = new Schema({
  "id": String,
  "name": String,
  "age": Number,
  "gender": String
});

module.exports = mongoose.model('Student',studentSchema);
