var mongoose = require('mongoose')
var Schema = mongoose.Schema;

var gradeSchema = new Schema({
  "className": String,
  "courseName": String,
  "classRoom": String,
  "startTime": String,
  "endTime": String,
  "stuTotal": Number
});

module.exports = mongoose.model('Grade',gradeSchema);
