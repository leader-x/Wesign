var mongoose = require('mongoose')
var Schema = mongoose.Schema;

var userSchema = new Schema({
  // "id": String,
  "userName": String,
  "password": String,
  "role": Number
});

module.exports = mongoose.model('User',userSchema);
